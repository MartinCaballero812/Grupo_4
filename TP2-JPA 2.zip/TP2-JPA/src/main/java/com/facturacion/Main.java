﻿package com.facturacion;

import com.facturacion.entities.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.Date;

public class Main {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            Usuario usuarioAdmin = new Usuario("admin", "1234", "Juan", "Pérez");
            em.persist(usuarioAdmin);

            Date ahora = new Date();

            PuntoVenta pv = new PuntoVenta();
            pv.setNumero(1);
            pv.setDescripcion("Punto de Venta Central");
            pv.setTipoEmision("Electronica");
            pv.setDomicilioComercial("Av. San Martín 1000");
            pv.setFechaAlta(ahora);
            pv.setFechaModificacion(ahora);
            pv.setUsuarioCarga(usuarioAdmin);
            pv.setUsuarioModificacion(usuarioAdmin);
            em.persist(pv);

            Rubro rubro = new Rubro();
            rubro.setCodigo(10);
            rubro.setDenominacion("Informatica");
            rubro.setFechaAlta(ahora);
            rubro.setFechaModificacion(ahora);
            rubro.setUsuarioCarga(usuarioAdmin);
            rubro.setUsuarioModificacion(usuarioAdmin);
            em.persist(rubro);

            Marca marca = new Marca();
            marca.setCodigo(20);
            marca.setDenominacion("Logitech");
            marca.setFechaAlta(ahora);
            marca.setFechaModificacion(ahora);
            marca.setUsuarioCarga(usuarioAdmin);
            marca.setUsuarioModificacion(usuarioAdmin);
            em.persist(marca);

            Articulo articulo = new Articulo();
            articulo.setCodigo("ART-001");
            articulo.setDenominacion("Mouse Inalámbrico");
            articulo.setRubro(rubro);
            articulo.setMarca(marca);
            articulo.setFechaAlta(ahora);
            articulo.setFechaModificacion(ahora);
            articulo.setUsuarioCarga(usuarioAdmin);
            articulo.setUsuarioModificacion(usuarioAdmin);
            em.persist(articulo);

            ListaPrecio listaPrecio = new ListaPrecio();
            listaPrecio.setCodigo("LP-01");
            listaPrecio.setDenominacion("Lista General Contado");
            listaPrecio.setFechaAlta(ahora);
            listaPrecio.setFechaModificacion(ahora);
            listaPrecio.setUsuarioCarga(usuarioAdmin);
            listaPrecio.setUsuarioModificacion(usuarioAdmin);
            em.persist(listaPrecio);

            ListaPrecioArticulo lpArticulo = new ListaPrecioArticulo();
            lpArticulo.setListaPrecio(listaPrecio);
            lpArticulo.setArticulo(articulo);
            lpArticulo.setPrecioVenta(15000.0);
            lpArticulo.setFechaAlta(ahora);
            lpArticulo.setFechaModificacion(ahora);
            lpArticulo.setUsuarioCarga(usuarioAdmin);
            lpArticulo.setUsuarioModificacion(usuarioAdmin);
            em.persist(lpArticulo);

            FacturaVenta factura = new FacturaVenta();
            factura.setNumero(1001L);
            factura.setFechaEmision(ahora);
            factura.setPuntoVenta(pv);
            factura.setEstado("EMITIDA");
            factura.setImporteTotal(30000.0);
            factura.setImporteCobrado(30000.0);
            factura.setImporteSaldo(0.0);
            factura.setFechaAlta(ahora);
            factura.setFechaModificacion(ahora);
            factura.setUsuarioCarga(usuarioAdmin);
            factura.setUsuarioModificacion(usuarioAdmin);

            FacturaVentaDetalle detalle1 = new FacturaVentaDetalle();
            detalle1.setListaPrecioArticulo(lpArticulo);
            detalle1.setDescripcion("Mouse Inalámbrico Logitech - Unidad 1");
            detalle1.setCantidad(1);
            detalle1.setPrecioUnitario(15000.0);
            detalle1.setImporteSubtotal(15000.0);

            FacturaVentaDetalle detalle2 = new FacturaVentaDetalle();
            detalle2.setListaPrecioArticulo(lpArticulo);
            detalle2.setDescripcion("Mouse Inalámbrico Logitech - Unidad 2");
            detalle2.setCantidad(1);
            detalle2.setPrecioUnitario(15000.0);
            detalle2.setImporteSubtotal(15000.0);

            factura.addDetalle(detalle1);
            factura.addDetalle(detalle2);

            // Persistencia en cascada: se persiste únicamente la cabecera
            em.persist(factura);

            em.getTransaction().commit();

            System.out.println("Factura grabada exitosamente con ID: " + factura.getId());
            System.out.println("Detalles guardados automaticamente en cascada: " + factura.getDetalles().size());

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}
