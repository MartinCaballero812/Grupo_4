# Upgrade Plan: TP2-JPA (20260909213519)

- **Generated**: 2026-09-09 21:35:19 UTC
- **HEAD Branch**: N/A (not a git repository)
- **HEAD Commit ID**: N/A (not a git repository)

## Available Tools

**JDKs**
- JDK 17: System JDK (current project JDK, used by baseline)
- JDK 21: **<TO_BE_INSTALLED>** (required by upgrade steps, target version)

**Build Tools**
- Maven 3.9.15+: **<TO_BE_INSTALLED>** (required for building and testing)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260909213519
- Run tests before and after the upgrade: true

## Upgrade Goals

- **Java**: 17 → 21 (latest LTS)

## Technology Stack

| Technology/Dependency    | Current | Target/Min Required | Why Updated |
| ------------------------ | ------- | ------------------- | ----------- |
| Java                     | 17      | 21                  | User requested Java 21 LTS upgrade |
| Hibernate JPA API        | 1.0.2.Final | 1.0.2.Final     | Already compatible with Java 21 |
| Hibernate Core           | 5.6.15.Final | 5.6.15.Final   | Already compatible with Java 21; 5.x supports Java 8-21+ |
| MySQL Connector          | 8.0.33  | 8.0.33              | Already compatible with Java 21 |
| Maven                    | (none)  | 3.9.15+             | Required build tool; 3.9.x recommended (3.8.x is EOL) |
| maven-compiler-plugin    | default | 3.11.0+             | Recommended for better Java 21 support |

## Derived Upgrades

- **Maven compiler plugin to 3.11.0+**: Explicitly added to pom.xml to ensure optimal Java 21 compilation support. Default compiler plugin may not be optimal for Java 21 features and optimizations.

## Impact Analysis

### Subsection: Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|-----------|---------|--------|--------|--------|
| pom.xml | maven.compiler.source | 17 | upgrade | 21 | User requested Java 21 upgrade |
| pom.xml | maven.compiler.target | 17 | upgrade | 21 | User requested Java 21 upgrade |
| pom.xml | maven-compiler-plugin | (none) | add | 3.11.0 | Explicit plugin for optimal Java 21 support |

### Subsection: Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| (none) | - | - | No source code changes required | Java 17→21 has no breaking compatibility changes for this project's code patterns |

### Subsection: Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|-----------------|---------|-----------------|--------|
| persistence.xml | schema version | 2.1 | No change | JPA 2.1 is compatible with Java 21 |

### Subsection: CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| (none) | - | - | No CI/CD files detected in project |

### Subsection: Risks & Warnings

- **No significant risks identified**: Java 17 to Java 21 is a minor LTS upgrade with high compatibility. This project uses standard Jakarta EE/JPA patterns with no internal reflection or module system concerns.

## Upgrade Steps

- **Step 1: Setup Environment**
  - **Rationale**: Ensure all required build tools and target JDK are available on the system.
  - **Changes to Make**: Install JDK 21 and Maven 3.9.15 if not already available.
  - **Verification**: Command: `java -version && mvn -version`; Expected Result: Both show correct versions (JDK 21.x, Maven 3.9.15+).

- **Step 2: Setup Baseline**
  - **Rationale**: Establish baseline compilation and test pass rate with current JDK 17 for comparison.
  - **Changes to Make**: Build and test the project with the current JDK 17.
  - **Verification**: Command: `mvn clean compile test-compile && mvn clean test`; Expected Result: Both commands complete successfully.

- **Step 3: Update pom.xml for Java 21**
  - **Rationale**: Update compiler source/target properties and add maven-compiler-plugin for optimal Java 21 support.
  - **Changes to Make**: Apply all Dependency Changes from Impact Analysis (update maven.compiler.source and maven.compiler.target to 21, add maven-compiler-plugin 3.11.0).
  - **Verification**: Command: `mvn clean test-compile -q`; Expected Result: Compilation succeeds with Java 21 compiler properties.

- **Step 4: Final Validation**
  - **Rationale**: Verify all upgrade goals are met and project is fully functional with Java 21.
  - **Changes to Make**: Ensure all TODOs and workarounds are resolved (none expected for this upgrade).
  - **Verification**: Command: `mvn clean test -q`; Expected Result: All tests pass with 100% pass rate. Build and runtime behavior is identical to Java 17 baseline.

