import type {
  CatalogosDTO,
  FacturaFiltrosDTO,
  FacturaReporteDTO,
  FacturaRequestDTO,
  PaginaFacturasDTO,
  PaginaDTO,
  ClienteExplorerDTO,
  ArticuloExplorerDTO,
  FacturaEdicionDTO
} from "./models/factura.dto.js";

const BASE_URL = "http://localhost:8080/api/facturas";

// Centraliza las llamadas HTTP al backend. Si la API responde con error, lanza un Error con el mensaje del servidor.
export class FacturaService {
  async obtenerCatalogos(): Promise<CatalogosDTO> {
    const respuesta = await this.obtenerConReintentos("http://localhost:8080/api/catalogos");
    return this.leerJson<CatalogosDTO>(respuesta);
  }

  async obtenerFacturas(
    filtros: FacturaFiltrosDTO = {},
    page = 0,
    size = 10,
  ): Promise<PaginaFacturasDTO> {
    const params = new URLSearchParams();
    for (const [clave, valor] of Object.entries(filtros)) {
      if (valor !== undefined && valor !== null && valor !== "") {
        params.append(clave, String(valor));
      }
    }
    params.append("page", String(page));
    params.append("size", String(size));
    const respuesta = await this.obtenerConReintentos(`${BASE_URL}?${params.toString()}`);
    return this.leerJson<PaginaFacturasDTO>(respuesta);
  }

  async crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
    const respuesta = await fetch(BASE_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(factura),
    });
    return this.leerJson<FacturaReporteDTO>(respuesta);
  }

    async actualizarEstado(id: number, estado: string, observaciones?: string, motivo?: string): Promise<FacturaReporteDTO> {
    const cuerpo: Partial<FacturaRequestDTO> = { estado, observaciones, motivo };
    const respuesta = await fetch(`${BASE_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(cuerpo), // lo que viene undefined no se envia: el servidor lo deja como estaba
    });
    return this.leerJson<FacturaReporteDTO>(respuesta);
  }

  async eliminarFactura(id: number): Promise<void> {
    const respuesta = await fetch(`${BASE_URL}/${id}`, { method: "DELETE" });
    if (!respuesta.ok) {
      throw new Error(await this.mensajeDeError(respuesta));
    }
  }
  async informarArca(id: number): Promise<FacturaReporteDTO> {
    const respuesta = await fetch(`${BASE_URL}/${id}/informar`, { method: "POST" });
    return this.leerJson<FacturaReporteDTO>(respuesta);
  }

  urlPdf(id: number): string {
    return `${BASE_URL}/${id}/pdf`;
  }

  async explorarClientes(texto: string, page: number, size: number): Promise<PaginaDTO<ClienteExplorerDTO>> {
    const params = new URLSearchParams({ texto, page: String(page), size: String(size) });
    const respuesta = await this.obtenerConReintentos(`http://localhost:8080/api/catalogos/clientes?${params}`);
    return this.leerJson<PaginaDTO<ClienteExplorerDTO>>(respuesta);
  }
  async explorarArticulos(texto: string, lista: string, page: number, size: number): Promise<PaginaDTO<ArticuloExplorerDTO>> {
    const params = new URLSearchParams({ texto, lista, page: String(page), size: String(size) });
    const respuesta = await this.obtenerConReintentos(`http://localhost:8080/api/catalogos/articulos?${params}`);
    return this.leerJson<PaginaDTO<ArticuloExplorerDTO>>(respuesta);
  }
  
    async obtenerFactura(id: number): Promise<FacturaEdicionDTO> {
    const respuesta = await fetch(`${BASE_URL}/${id}`);
    return this.leerJson<FacturaEdicionDTO>(respuesta);
  }

  async actualizarFactura(id: number, factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
    const respuesta = await fetch(`${BASE_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(factura),
    });
    return this.leerJson<FacturaReporteDTO>(respuesta);
  }
  
  private async leerJson<T>(respuesta: Response): Promise<T> {
    if (!respuesta.ok) {
      throw new Error(await this.mensajeDeError(respuesta));
    }
    return (await respuesta.json()) as T;
  }
  

  private async obtenerConReintentos(url: string): Promise<Response> {
    for (let intento = 0; intento < 5; intento++) {
      try {
        return await fetch(url);
      } catch (error) {
        if (intento === 4) throw error;
        await new Promise((resolve) => setTimeout(resolve, 500 * 2 ** intento));
      }
    }
    throw new Error("No se pudo conectar con el servidor");
  }

  // El backend responde {"error": "...", "mensaje": "..."}; si no viene ese formato se muestra el codigo HTTP.
  private async mensajeDeError(respuesta: Response): Promise<string> {
    try {
      const cuerpo = (await respuesta.json()) as { mensaje?: string };
      if (cuerpo.mensaje) {
        return cuerpo.mensaje;
      }
    } catch {
      // el cuerpo no era JSON
    }
    return `Error ${respuesta.status} ${respuesta.statusText}`.trim();
  }
}