

// Respuesta de GET (items), POST y PUT  <->  FacturaReporteDTO.java
export interface FacturaReporteDTO {
  id: number;
  numeroFactura: number;
  fechaEmision: string;
  clienteDenominacion: string;
  condicionIva: string;
  puntoVentaDescripcion: string;
  estado: string;
  importeTotal: number;
  cantidadItems: number;
  cae?: string;
  moneda: string;
  observaciones?: string;
  motivo?: string;

}

// Respuesta de GET /api/facturas (la arma FacturaRestController con un Map)
export interface PaginaFacturasDTO {
  items: FacturaReporteDTO[];
  total: number;
  page: number;
  size: number;
}

// Renglon de la factura  <->  FacturaDetalleRequestDTO.java
export interface FacturaDetalleRequestDTO {
  articuloId: number;
  cantidad: number;
  descripcion?: string;
  porcentajeBonificacion?: number;

}

// Cuerpo de POST y PUT  <->  FacturaRequestDTO.java
// En el POST son obligatorios condicionIvaId, puntoVentaId, tipoMonedaId y detalles; en el PUT se usa Partial<>.
export interface FacturaRequestDTO {
  clienteId?: number;
  condicionIvaId: number;
  puntoVentaId: number;
  tipoMonedaId: number;
  estado?: string;
  observaciones?: string;
  detalles: FacturaDetalleRequestDTO[];
  motivo?: string;
  sinCliente?: boolean;
}

// Query params de GET /api/facturas (@RequestParam del controller). No es un DTO de Java.
export interface FacturaFiltrosDTO {
  fechaDesde?: string;
  fechaHasta?: string;
  estado?: string;
  montoMinimo?: number;
  numeroFactura?: number;
  clienteId?: number;
  informada?: boolean; // true = informadas a ARCA (con CAE), false = no informadas
}

export interface OpcionCatalogoDTO {
  id: number;
  descripcion: string;
}

export interface CatalogosDTO {
  clientes: OpcionCatalogoDTO[];
  condicionesIva: OpcionCatalogoDTO[];
  puntosVenta: OpcionCatalogoDTO[];
  monedas: OpcionCatalogoDTO[];
  articulos: OpcionCatalogoDTO[];
}

export interface PaginaDTO<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
}

export interface ClienteExplorerDTO {
  id: number;
  denominacion: string;
  cuitCuil: string;
}

export interface ArticuloExplorerDTO {
  id: number;
  articuloId: number;
  codigo: string;
  articulo: string;
  rubro: string;
  marca: string;
  listaPrecio: string;
  precioVenta: number;
  stock: number;
  cantidadMinima: number;
  disponible: boolean;
  disponibilidad: string;
  
  
  
}
export interface FacturaDetalleEdicionDTO {
  listaPrecioArticuloId: number;
  articuloId: number;
  descripcion: string;
  cantidad: number;
  porcentajeBonificacion: number;
}

export interface FacturaEdicionDTO {
  id: number;
  numeroFactura: number;
  estado: string;
  clienteId?: number;
  clienteTexto?: string;
  condicionIvaId: number;
  puntoVentaId: number;
  tipoMonedaId: number;
  observaciones?: string;
  detalles: FacturaDetalleEdicionDTO[];
}

export interface FacturaDetalleEdicionDTO {
  listaPrecioArticuloId: number;
  articuloId: number;
  descripcion: string;
  cantidad: number;
  porcentajeBonificacion: number;
  precioVenta: number;
}