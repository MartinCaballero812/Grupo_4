import { FacturaService } from "./FacturaService.js";
import type {
  FacturaDetalleRequestDTO,
  FacturaFiltrosDTO,
  FacturaReporteDTO,
  FacturaRequestDTO,
  CatalogosDTO,
  OpcionCatalogoDTO,
} from "./models/factura.dto.js";

const TAMANIO_PAGINA = 10;
const TAMANIO_MODAL = 8;
const CLIENTE_POR_DEFECTO = "Consumidor Final";

const servicio = new FacturaService();
let items: FacturaDetalleRequestDTO[] = [];
let catalogos: CatalogosDTO | undefined;
let paginaActual = 0;
let clienteSeleccionadoId: number | undefined;
let articuloSeleccionadoId: number | undefined;
let filtroClienteId: number | undefined; // cliente elegido en el filtro de comprobantes
let destinoCliente: "factura" | "filtro" = "factura"; // desde que campo se abrio el modal de clientes
let facturaEnEdicionId: number | undefined; // si tiene valor, el formulario esta editando esa factura
const devueltoPorEdicion = new Map<number, number>(); // id de Articulo -> unidades que la factura editada ya tiene reservadas
let listaArticulos = ""; // vacia hasta que se elige una lista en el desplegable
let minimoSeleccionado = 1;
let stockSeleccionado = Infinity;

let articuloIdSeleccionado: number | undefined; // id del Articulo: el stock es del articulo, no de la lista
const articuloDeLista = new Map<number, number>(); // id de ListaPrecioArticulo -> id de Articulo
let textoSeleccionado = ""; // texto del articulo elegido en el modal (con marca, lista y precio)
const descripcionDeLista = new Map<number, string>(); // id de ListaPrecioArticulo -> texto para mostrar en la tabla de items

const precioDeLista = new Map<number, number>(); // id de ListaPrecioArticulo -> precio de lista (sin bonificacion)
let precioSeleccionado = 0; // precio del articulo elegido en el modal

function $<T extends HTMLElement>(id: string): T {
  const el = document.getElementById(id);
  if (!el) throw new Error(`No existe el elemento #${id}`);
  return el as T;
}

function numeroOpcional(valor: string): number | undefined {
  const limpio = valor.trim();
  if (limpio === "") return undefined;
  const n = Number(limpio);
  return Number.isFinite(n) ? n : undefined;
}
function mostrarMensaje(texto: string, esError = false): void {
  const el = $<HTMLParagraphElement>("mensaje");
  el.textContent = texto;
  el.className = esError ? "error" : "ok";
  el.hidden = false;
  el.scrollIntoView({ behavior: "smooth", block: "center" });
}

function textoDeError(e: unknown): string {
  return e instanceof Error ? e.message : "Ocurrió un error inesperado";
}

function formatoMonto(n: number): string {
  return n.toLocaleString("es-AR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function llenarSelect(id: string, opciones: OpcionCatalogoDTO[]): void {
  const select = $<HTMLSelectElement>(id);
  for (const opcion of opciones) {
    const elemento = document.createElement("option");
    elemento.value = String(opcion.id);
    elemento.textContent = opcion.descripcion;
    select.append(elemento);
  }
}

async function cargarCatalogos(): Promise<void> {
  try {
    catalogos = await servicio.obtenerCatalogos();
    llenarSelect("a-iva", catalogos.condicionesIva);
    llenarSelect("a-pv", catalogos.puntosVenta);
    llenarSelect("a-moneda", catalogos.monedas);
    dibujarItems();
  } catch (e) {
    mostrarMensaje(`No se pudieron cargar las opciones: ${textoDeError(e)}`, true);
  }
}

function celda(texto: string, clase?: string): HTMLTableCellElement {
  const td = document.createElement("td");
  td.textContent = texto;
  if (clase) td.className = clase;
  return td;
}

function boton(texto: string, clase: string, alClick: () => void): HTMLButtonElement {
  const b = document.createElement("button");
  b.type = "button";
  b.textContent = texto;
  b.className = clase;
  b.addEventListener("click", alClick);
  return b;
}

function subtotalDeItem(item: { articuloId: number; cantidad?: number; porcentajeBonificacion?: number }): number {
  const redondear = (n: number) => Math.round(n * 100) / 100;
  const precio = precioDeLista.get(item.articuloId) ?? 0;
  const bruto = redondear((item.cantidad ?? 0) * precio);                          // precio x cantidad
  const neto = redondear(bruto * (1 - (item.porcentajeBonificacion ?? 0) / 100));  // con bonificación
  const iva = redondear(neto * 0.21);                                              // IVA 21%
  return redondear(neto + iva);                                                    
}

function dibujarItems(): void {
  const cuerpo = $<HTMLTableSectionElement>("items-body");
  cuerpo.replaceChildren();
  let total = 0;
  items.forEach((item, indice) => {
    const subtotal = subtotalDeItem(item);
    total += subtotal;
    const fila = document.createElement("tr");
    fila.append(
      celda(descripcionDeLista.get(item.articuloId)
        ?? catalogos?.articulos.find((articulo) => articulo.id === item.articuloId)?.descripcion
        ?? String(item.articuloId)),
      celda(String(item.cantidad), "num"),
      celda(`${item.porcentajeBonificacion ?? 0} %`, "num"),
      celda(`$ ${formatoMonto(subtotal)}`, "num"),
    );
    const acciones = document.createElement("td");
    acciones.append(
      boton("Quitar", "sec", () => {
        items.splice(indice, 1);
        dibujarItems();
      }),
    );
    fila.append(acciones);
    cuerpo.append(fila);
  });
  $("items-vacio").hidden = items.length > 0;
      $<HTMLElement>("items-total").textContent = `Total: $ ${formatoMonto(Math.round(total * 100) / 100)}`;
}

// Unidades de un articulo que ya estan cargadas en la factura que se esta armando (se descuentan del stock).
function reservadoDe(articuloId: number): number {
  return items
    .filter((item) => articuloDeLista.get(item.articuloId) === articuloId)
    .reduce((suma, item) => suma + (item.cantidad ?? 0), 0);
}
async function agregarItem(): Promise<void> {
  const cantidad = numeroOpcional($<HTMLInputElement>("i-cantidad").value);
  const bonificacion = numeroOpcional($<HTMLInputElement>("i-bonif").value) ?? 0;
  const libre = articuloIdSeleccionado === undefined
    ? stockSeleccionado
    : stockSeleccionado + (devueltoPorEdicion.get(articuloIdSeleccionado) ?? 0) - reservadoDe(articuloIdSeleccionado);

  if (articuloSeleccionadoId === undefined || articuloIdSeleccionado === undefined) {
    mostrarMensaje("Seleccioná un artículo.", true);
  } else if (libre <= 0) {
    mostrarMensaje("Ya no hay stock disponible de este artículo.", true);
  } else if (cantidad === undefined || !Number.isInteger(cantidad) || cantidad < 1) {
    mostrarMensaje("La cantidad debe ser un número entero mayor a 0.", true);
  } else if (cantidad > libre) {
    mostrarMensaje(`Solo quedan ${libre} unidades disponibles de este artículo.`, true);
  } else if (bonificacion < 0 || bonificacion > 100) {
    mostrarMensaje("La bonificación debe estar entre 0 y 100.", true);
  } else {
    try {
      const idLista = articuloSeleccionadoId;
      const texto = textoSeleccionado;
      articuloDeLista.set(idLista, articuloIdSeleccionado);
      descripcionDeLista.set(idLista, texto);
      precioDeLista.set(idLista, precioSeleccionado);
      items.push({ articuloId: idLista, cantidad, porcentajeBonificacion: bonificacion });
      quitarArticulo();
      $<HTMLInputElement>("i-cantidad").value = "1";
      $<HTMLInputElement>("i-bonif").value = "0";
      $("mensaje").hidden = true;
      dibujarItems();
    } catch (e) {
      mostrarMensaje(textoDeError(e), true);
    }
  }
}


function leerFiltros(): FacturaFiltrosDTO {
  const informada = $<HTMLSelectElement>("f-informada").value;
  return {
    fechaDesde: $<HTMLInputElement>("f-desde").value || undefined,
    fechaHasta: $<HTMLInputElement>("f-hasta").value || undefined,
    estado: $<HTMLSelectElement>("f-estado").value || undefined,
    montoMinimo: numeroOpcional($<HTMLInputElement>("f-monto").value),
    numeroFactura: numeroOpcional($<HTMLInputElement>("f-numero").value),
    clienteId: filtroClienteId,
    informada: informada === "" ? undefined : informada === "true",
  };
}

function dibujarListado(facturas: FacturaReporteDTO[]): void {
  const cuerpo = $<HTMLTableSectionElement>("facturas-body");
  cuerpo.replaceChildren();

  // El orden (numero descendente) lo resuelve el servidor para que sea consistente entre paginas.
  for (const f of facturas) {
    const fila = document.createElement("tr");
    const estado = document.createElement("td");
    const etiqueta = document.createElement("span");
    etiqueta.textContent = f.estado;
    etiqueta.className = f.estado === "ANULADA" ? "estado anulada" : "estado";
    estado.append(etiqueta);

    const acciones = document.createElement("td");
    acciones.className = "acciones";
        if (f.observaciones) {
      acciones.append(boton("Ver observaciones", "sec", () => verTexto("Observaciones", f.observaciones ?? "")));
    }

    
    if (f.motivo) {
      const titulo = f.estado === "ANULADA" ? "Motivo de la anulación" : "Motivo del rechazo";
      acciones.append(boton("Ver motivo", "sec", () => verTexto(titulo, f.motivo ?? "")));
    }

    if (!f.cae && f.estado !== "ANULADA") {
      acciones.append(boton("Informar a ARCA", "sec", () => void informar(f)));
    }
    if (f.cae) {
      acciones.append(boton("Imprimir PDF", "sec", () => window.open(servicio.urlPdf(f.id), "_blank")));
    }

        if (!f.cae && f.estado !== "ANULADA") {
      acciones.append(boton("Editar", "sec", () => void editar(f))); // informada: no se modifica
    }

        if (f.estado !== "ANULADA") {
      acciones.append(boton("Anular", "sec", () => void anular(f)));
    }
    if (!f.cae) {
      acciones.append(boton("Eliminar", "peligro", () => void eliminar(f)));
    }

    fila.append(
      celda(String(f.numeroFactura)),
      celda(f.fechaEmision),
      celda(f.clienteDenominacion),
      celda(f.condicionIva),
      celda(f.puntoVentaDescripcion),
      estado,
      celda(f.moneda),
      celda(formatoMonto(f.importeTotal), "num"),
      celda(String(f.cantidadItems), "num"),
      acciones,
    );
    cuerpo.append(fila);
  }
  $("facturas-vacio").hidden = facturas.length > 0;
}

function dibujarPaginacion(total: number, pagina: number, tamanio: number): void {
  const contenedor = $<HTMLDivElement>("paginacion");
  contenedor.replaceChildren();
  const totalPaginas = Math.max(1, Math.ceil(total / tamanio));

  const anterior = boton("« Anterior", "sec", () => void cargarListado(paginaActual - 1));
  anterior.disabled = pagina <= 0;

  const info = document.createElement("span");
  info.className = "pag-info";
  info.textContent = `Página ${pagina + 1} de ${totalPaginas} (${total} comprobantes)`;

  const siguiente = boton("Siguiente »", "sec", () => void cargarListado(paginaActual + 1));
  siguiente.disabled = pagina + 1 >= totalPaginas;

  contenedor.append(anterior, info, siguiente);
}

async function cargarListado(pagina = paginaActual): Promise<void> {
  try {
    const resultado = await servicio.obtenerFacturas(leerFiltros(), pagina, TAMANIO_PAGINA);

    // Si la pagina quedo vacia (ej. se elimino el ultimo item de la ultima pagina), volver a la ultima que exista.
    if (resultado.items.length === 0 && resultado.total > 0 && pagina > 0) {
      await cargarListado(Math.ceil(resultado.total / TAMANIO_PAGINA) - 1);
      return;
    }

    paginaActual = resultado.page;
    dibujarListado(resultado.items);
    dibujarPaginacion(resultado.total, resultado.page, resultado.size);
  } catch (e) {
    mostrarMensaje(`No se pudo cargar el listado: ${textoDeError(e)}`, true);
  }
}
// ---------- Aviso de confirmacion (reemplaza confirm / prompt del navegador) ----------
function abrirAviso(
  titulo: string,
  texto: string,
  soloLectura: boolean,
  pedirMotivo = false,
): Promise<{ aceptado: boolean; motivo?: string }> {
  return new Promise((resolver) => {
    const modal = $<HTMLElement>("modal-aviso");
    const motivo = $<HTMLInputElement>("aviso-motivo");
    const aceptar = $<HTMLButtonElement>("aviso-aceptar");
    const cancelar = $<HTMLButtonElement>("aviso-cancelar");

    $<HTMLElement>("aviso-titulo").textContent = titulo;
    $<HTMLElement>("aviso-texto").textContent = texto;
    motivo.value = "";
    motivo.hidden = !pedirMotivo;
    cancelar.hidden = soloLectura;
    aceptar.textContent = soloLectura ? "Cerrar" : "Aceptar";
    modal.hidden = false;
    aceptar.focus();

    const cerrar = (aceptado: boolean): void => {
      modal.hidden = true;
      aceptar.onclick = null;
      cancelar.onclick = null;
      resolver({ aceptado, motivo: motivo.value.trim() || undefined });
    };
    aceptar.onclick = () => cerrar(true);
    cancelar.onclick = () => cerrar(false);
  });
}

// Pregunta si/no (siempre, sin opcion de silenciarla)
function confirmarAviso(texto: string, pedirMotivo = false): Promise<{ aceptado: boolean; motivo?: string }> {
  return abrirAviso("Aviso", texto, false, pedirMotivo);
}

// Muestra un texto (observaciones, motivo) con un solo boton para cerrar
function verTexto(titulo: string, texto: string): void {
  void abrirAviso(titulo, texto, true);
}
async function anular(f: FacturaReporteDTO): Promise<void> {
  const { aceptado, motivo } = await confirmarAviso(`¿Anular la factura N° ${f.numeroFactura}?`, true);
  if (!aceptado) return;
  try {
    await servicio.actualizarEstado(f.id, "ANULADA", undefined, motivo);
    mostrarMensaje(`Factura N° ${f.numeroFactura} anulada.`);
    await cargarListado();
  } catch (e) {
    mostrarMensaje(`No se pudo anular: ${textoDeError(e)}`, true);
  }
}

async function informar(f: FacturaReporteDTO): Promise<void> {
   const { aceptado } = await confirmarAviso(
    `¿Informar a ARCA la factura N° ${f.numeroFactura}? Una vez informada no se podrá modificar ni eliminar, solo anular.`,
  );
  if (!aceptado) return;
  try {
    const r = await servicio.informarArca(f.id);
    if (r.cae) {
      mostrarMensaje(`Factura N° ${r.numeroFactura} informada a ARCA. CAE: ${r.cae}.`);
    } else {
      mostrarMensaje(`ARCA rechazó la factura N° ${r.numeroFactura}.`, true);
    }
    await cargarListado();
  } catch (e) {
    mostrarMensaje(`No se pudo informar a ARCA: ${textoDeError(e)}`, true);
  }
}

async function eliminar(f: FacturaReporteDTO): Promise<void> {
  const { aceptado } = await confirmarAviso(
    `¿Eliminar definitivamente la factura N° ${f.numeroFactura}? Esta acción no se puede deshacer.`,
  );
  if (!aceptado) return;
  try {
    await servicio.eliminarFactura(f.id);
    mostrarMensaje(`Factura N° ${f.numeroFactura} eliminada.`);
    await cargarListado();
  } catch (e) {
    mostrarMensaje(`No se pudo eliminar: ${textoDeError(e)}`, true);
  }
}

// ---------- Paginacion de los modales ----------

function dibujarPaginaModal(contenedorId: string, total: number, pagina: number, alCambiar: (p: number) => void): void {
  const contenedor = $<HTMLDivElement>(contenedorId);
  contenedor.replaceChildren();
  const totalPaginas = Math.max(1, Math.ceil(total / TAMANIO_MODAL));

  const anterior = boton("«", "sec", () => alCambiar(pagina - 1));
  anterior.disabled = pagina <= 0;

  const info = document.createElement("span");
  info.className = "pag-info";
  info.textContent = `Página ${pagina + 1} de ${totalPaginas}`;

  const siguiente = boton("»", "sec", () => alCambiar(pagina + 1));
  siguiente.disabled = pagina + 1 >= totalPaginas;

  contenedor.append(anterior, info, siguiente);
}

// ---------- Modal Buscar Cliente ----------

function abrirModalCliente(destino: "factura" | "filtro"): void {
  destinoCliente = destino;
  $<HTMLElement>("modal-cliente").hidden = false;
  void buscarCliente(0);
}

function cerrarModalCliente(): void {
  $<HTMLElement>("modal-cliente").hidden = true;
}

async function buscarCliente(pagina = 0): Promise<void> {
  try {
    const texto = $<HTMLInputElement>("busqueda-cliente").value.trim();
    const resultado = await servicio.explorarClientes(texto, pagina, TAMANIO_MODAL);
    const cuerpo = $<HTMLTableSectionElement>("resultados-cliente");
    cuerpo.replaceChildren();
    for (const c of resultado.items) {
      const accion = document.createElement("td");
            accion.append(
        boton("Seleccionar", "sec", () => {
          const texto = `${c.denominacion} - ${c.cuitCuil}`;
          if (destinoCliente === "filtro") {
            filtroClienteId = c.id;
            $<HTMLInputElement>("f-cliente-texto").value = texto;
          } else {
            clienteSeleccionadoId = c.id;
            $<HTMLInputElement>("a-cliente-texto").value = texto;
          }
          cerrarModalCliente();
        }),
      );
      
      const fila = document.createElement("tr");
      fila.append(celda(c.denominacion), celda(c.cuitCuil), accion);
      cuerpo.append(fila);
    }
    dibujarPaginaModal("paginacion-cliente", resultado.total, resultado.page, (p) => void buscarCliente(p));
  } catch (e) {
    mostrarMensaje(`No se pudieron buscar clientes: ${textoDeError(e)}`, true);
  }
}function quitarCliente(): void {
  clienteSeleccionadoId = undefined;
  $<HTMLInputElement>("a-cliente-texto").value = CLIENTE_POR_DEFECTO;
}
function quitarClienteFiltro(): void {
  filtroClienteId = undefined;
  $<HTMLInputElement>("f-cliente-texto").value = "Todos";
}


$<HTMLButtonElement>("btn-quitar-cliente").addEventListener("click", quitarCliente);
$<HTMLButtonElement>("btn-buscar-cliente").addEventListener("click", () => void buscarCliente(0));
$<HTMLButtonElement>("btn-cerrar-modal-cliente").addEventListener("click", cerrarModalCliente);

$<HTMLButtonElement>("btn-abrir-modal-cliente").addEventListener("click", () => abrirModalCliente("factura"));
$<HTMLButtonElement>("btn-abrir-modal-cliente-filtro").addEventListener("click", () => abrirModalCliente("filtro"));
$<HTMLButtonElement>("btn-quitar-cliente-filtro").addEventListener("click", quitarClienteFiltro);
// ---------- Modal Buscar Artículo (ListaPrecioArticulo) ----------

function actualizarTextoLista(): void {
  const titulo = listaArticulos === "MAYORISTA" ? " — Lista mayorista"
    : listaArticulos === "MINORISTA" ? " — Lista minorista" : "";
  $<HTMLElement>("lista-articulo-actual").textContent = titulo;
}

function mostrarSinSeleccion(): void {
  const cuerpo = $<HTMLTableSectionElement>("resultados-articulo");
  cuerpo.replaceChildren();
  const fila = document.createElement("tr");
  const td = celda("No has seleccionado ninguna lista de precio", "sin-seleccion");
  td.colSpan = 9;
  fila.append(td);
  cuerpo.append(fila);
  $<HTMLElement>("paginacion-articulo").replaceChildren();
}

function abrirModalArticulo(): void {
  listaArticulos = ""; // al abrir no hay lista elegida: la tabla aparece en blanco
  $<HTMLSelectElement>("select-lista-precio").value = "";
  $<HTMLInputElement>("busqueda-articulo").value = "";
  actualizarTextoLista();
  mostrarSinSeleccion();
  $<HTMLElement>("modal-articulo").hidden = false;
}

function cerrarModalArticulo(): void {
  $<HTMLElement>("modal-articulo").hidden = true;
}

function cambiarLista(): void {
  listaArticulos = $<HTMLSelectElement>("select-lista-precio").value;
  actualizarTextoLista();
  if (listaArticulos === "") {
    mostrarSinSeleccion();
  } else {
    void buscarArticulo(0);
  }
}

async function buscarArticulo(pagina = 0): Promise<void> {
  if (listaArticulos === "") {
    mostrarSinSeleccion(); // sin lista elegida no se muestra ningun articulo
    return;
  }
  try {
    const texto = $<HTMLInputElement>("busqueda-articulo").value.trim();
    const resultado = await servicio.explorarArticulos(texto, listaArticulos, pagina, TAMANIO_MODAL);
    const cuerpo = $<HTMLTableSectionElement>("resultados-articulo");
    cuerpo.replaceChildren();
    for (const a of resultado.items) {
      // Lo que ya agregaste a esta factura se descuenta del stock que ves
      const libre = a.stock + (devueltoPorEdicion.get(a.articuloId) ?? 0) - reservadoDe(a.articuloId);
      const disponible = libre >= a.cantidadMinima;
      const disponibilidad = libre <= 0
        ? "Sin stock"
        : disponible
          ? "Disponible"
          : "Stock insuficiente";

      const accion = document.createElement("td");
      const seleccionar = boton("Seleccionar", "sec", () => {
        articuloSeleccionadoId = a.id;
        articuloIdSeleccionado = a.articuloId;
        minimoSeleccionado = a.cantidadMinima;
        stockSeleccionado = a.stock;
        precioSeleccionado = a.precioVenta;
         textoSeleccionado = `${a.codigo} - ${a.articulo} | ${a.marca} | ${a.listaPrecio} | $ ${formatoMonto(a.precioVenta)}`;
        $<HTMLInputElement>("i-articulo-texto").value = textoSeleccionado;
        cerrarModalArticulo();
      });
      if (disponible) {
        accion.append(seleccionar); // sin stock (o sin stock mayorista) el boton no aparece
      }

      const fila = document.createElement("tr");
      fila.append(
        celda(a.codigo),
        celda(a.articulo),
        celda(a.rubro),
        celda(a.marca),
        celda(a.listaPrecio),
        celda(formatoMonto(a.precioVenta), "num"),
        celda(String(libre), "num"),
        celda(disponibilidad, `disponibilidad ${disponible ? "disponible" : "no-disponible"}`),
        accion,
      );
      cuerpo.append(fila);
    }
    dibujarPaginaModal("paginacion-articulo", resultado.total, resultado.page, (p) => void buscarArticulo(p));
  } catch (e) {
    mostrarMensaje(`No se pudieron buscar artículos: ${textoDeError(e)}`, true);
  }
}

function quitarArticulo(): void {
  articuloSeleccionadoId = undefined;
  articuloIdSeleccionado = undefined;
  textoSeleccionado = "";
  minimoSeleccionado = 1;
  stockSeleccionado = Infinity;
  $<HTMLInputElement>("i-articulo-texto").value = "";
}
$<HTMLButtonElement>("btn-abrir-modal-articulo").addEventListener("click", abrirModalArticulo);
$<HTMLButtonElement>("btn-quitar-articulo").addEventListener("click", quitarArticulo);
$<HTMLButtonElement>("btn-buscar-articulo").addEventListener("click", () => void buscarArticulo(0));
$<HTMLSelectElement>("select-lista-precio").addEventListener("change", cambiarLista);
$<HTMLButtonElement>("btn-cerrar-modal-articulo").addEventListener("click", cerrarModalArticulo);

// ---------- Filtros ----------

$<HTMLFormElement>("form-filtros").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  await cargarListado(0); // una busqueda nueva siempre arranca en la primera pagina
  $<HTMLElement>("t-lista").scrollIntoView({ behavior: "smooth", block: "start" }); // baja hasta "Comprobantes registrados"
});

$<HTMLFormElement>("form-filtros").addEventListener("reset", () => {
  filtroClienteId = undefined; // el campo de texto vuelve solo a "Todos"
  setTimeout(() => void cargarListado(0), 0);
});
// ---------- Edicion de una factura (solo si no esta informada ni anulada) ----------
function abrirPanelFactura(): void {
  $<HTMLElement>("panel-factura").hidden = false;
}

function cerrarPanelFactura(): void {
  $<HTMLElement>("panel-factura").hidden = true;
}

$<HTMLButtonElement>("btn-nueva-factura").addEventListener("click", () => {
  const panel = $<HTMLElement>("panel-factura");
  if (panel.hidden) {
    if (facturaEnEdicionId !== undefined) reiniciarFormulario(); // si estaba editando, arranca una factura nueva
    abrirPanelFactura();
    $<HTMLElement>("t-alta").scrollIntoView({ behavior: "smooth", block: "start" });
  } else {
    cerrarPanelFactura();
  }
});

function reiniciarFormulario(): void {
  facturaEnEdicionId = undefined;
  devueltoPorEdicion.clear();
  items = [];
  quitarCliente();
  quitarArticulo();
  $<HTMLFormElement>("form-factura").reset();
  $<HTMLElement>("t-alta").textContent = "Nueva factura";
  $<HTMLButtonElement>("btn-guardar-factura").textContent = "Guardar factura";
  $<HTMLButtonElement>("btn-cancelar-edicion").hidden = true;
  dibujarItems();
}

async function editar(f: FacturaReporteDTO): Promise<void> {
  if (items.length > 0 || facturaEnEdicionId !== undefined) {
    const { aceptado } = await confirmarAviso(
      `El formulario tiene datos sin guardar. ¿Descartarlos y editar la factura N° ${f.numeroFactura}?`,
    );
    if (!aceptado) return;
  }
  try {
    const factura = await servicio.obtenerFactura(f.id);
    reiniciarFormulario();

    facturaEnEdicionId = factura.id;
    for (const d of factura.detalles) {
      items.push({
        articuloId: d.listaPrecioArticuloId,
        cantidad: d.cantidad,
        porcentajeBonificacion: d.porcentajeBonificacion,
      });
      descripcionDeLista.set(d.listaPrecioArticuloId, d.descripcion);
      precioDeLista.set(d.listaPrecioArticuloId, d.precioVenta);
      articuloDeLista.set(d.listaPrecioArticuloId, d.articuloId);
      devueltoPorEdicion.set(d.articuloId, (devueltoPorEdicion.get(d.articuloId) ?? 0) + d.cantidad);
    }

    clienteSeleccionadoId = factura.clienteId ?? undefined;
    $<HTMLInputElement>("a-cliente-texto").value = factura.clienteTexto ?? CLIENTE_POR_DEFECTO;
    $<HTMLSelectElement>("a-iva").value = String(factura.condicionIvaId);
    $<HTMLSelectElement>("a-pv").value = String(factura.puntoVentaId);
    $<HTMLSelectElement>("a-moneda").value = String(factura.tipoMonedaId);
    $<HTMLInputElement>("a-obs").value = factura.observaciones ?? "";

    $<HTMLElement>("t-alta").textContent = `Editar factura N° ${factura.numeroFactura}`;
    $<HTMLButtonElement>("btn-guardar-factura").textContent = "Guardar cambios";
    $<HTMLButtonElement>("btn-cancelar-edicion").hidden = false;
    dibujarItems();
    $<HTMLElement>("t-alta").scrollIntoView({ behavior: "smooth", block: "start" });
        abrirPanelFactura(); // al editar se despliega el formulario
  } catch (e) {
    mostrarMensaje(`No se puede editar la factura: ${textoDeError(e)}`, true);
  }
}

$<HTMLButtonElement>("btn-cancelar-edicion").addEventListener("click", () => {
  reiniciarFormulario();
  cerrarPanelFactura();
});
// ---------- Alta ----------

$<HTMLButtonElement>("i-agregar").addEventListener("click", agregarItem);
$<HTMLFormElement>("form-factura").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  if (items.length === 0) {
    mostrarMensaje("Agregá al menos un ítem antes de guardar la factura.", true);
    return;
  }
  const factura: FacturaRequestDTO = {
    clienteId: clienteSeleccionadoId,
    condicionIvaId: Number($<HTMLSelectElement>("a-iva").value),
    puntoVentaId: Number($<HTMLSelectElement>("a-pv").value),
    tipoMonedaId: Number($<HTMLSelectElement>("a-moneda").value),
    observaciones: $<HTMLInputElement>("a-obs").value.trim() || undefined,
    detalles: [...items],
  };
  const estabaEditando = facturaEnEdicionId !== undefined;
  try {
    if (facturaEnEdicionId !== undefined) {
      // Edicion (PUT). sinCliente = true le dice al servidor que la factura pasa a Consumidor Final
      const actualizada = await servicio.actualizarFactura(facturaEnEdicionId, {
        ...factura,
        sinCliente: clienteSeleccionadoId === undefined,
      });
      mostrarMensaje(`Factura N° ${actualizada.numeroFactura} actualizada. Total: ${formatoMonto(actualizada.importeTotal)}.`);
    } else {
      const creada = await servicio.crearFactura(factura);
      mostrarMensaje(`Factura N° ${creada.numeroFactura} creada. Total: ${formatoMonto(creada.importeTotal)}.`);
    }
    reiniciarFormulario();
      cerrarPanelFactura();
    await cargarListado(estabaEditando ? paginaActual : 0); // al editar se queda en la misma pagina
  } catch (e) {
    mostrarMensaje(`No se pudo guardar la factura: ${textoDeError(e)}`, true);
  }
});

dibujarItems();
void cargarListado(0);
void cargarCatalogos();

