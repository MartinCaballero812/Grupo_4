package ar.edu.facturacion.controller;

import ar.edu.facturacion.dto.FacturaEdicionDTO;

import ar.edu.facturacion.service.FacturaPdfService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import ar.edu.facturacion.dto.FacturaReporteDTO;
import ar.edu.facturacion.dto.FacturaRequestDTO;
import ar.edu.facturacion.service.FacturaService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.net.URI;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/facturas")
public class FacturaRestController {
    private final FacturaService service;

    private final FacturaPdfService pdfService;

    public FacturaRestController(FacturaService service, FacturaPdfService pdfService) {
        this.service = service;
        this.pdfService = pdfService;
    }

    // 200 OK + {items, total, page, size}
    @GetMapping
    public ResponseEntity<Map<String, Object>> listar(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaDesde,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo,
            @RequestParam(required = false) Long numeroFactura,
            @RequestParam(required = false) Long clienteId,
            @RequestParam(required = false) Boolean informada,   // true = con CAE, false = sin CAE, null = todas
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {

        int p = (page == null || page < 0) ? 0 : page;
        int s = (size == null || size <= 0) ? 10 : size;

        List<FacturaReporteDTO> items = service.buscarFacturasFiltradas(
                fechaDesde, fechaHasta, estado, montoMinimo, numeroFactura, clienteId, informada, p, s);
        long total = service.contarFacturasFiltradas(
                fechaDesde, fechaHasta, estado, montoMinimo, numeroFactura, clienteId, informada);

        Map<String, Object> resp = new HashMap<>();
        resp.put("items", items);
        resp.put("total", total);
        resp.put("page", p);
        resp.put("size", s);
        return ResponseEntity.ok(resp);
    }

    // 201 Created + FacturaReporteDTO de la factura creada (y header Location con su URL)
    @PostMapping
    public ResponseEntity<FacturaReporteDTO> crear(@RequestBody FacturaRequestDTO dto) {
        FacturaReporteDTO creada = service.crear(dto);
        return ResponseEntity.created(URI.create("/api/facturas/" + creada.getId())).body(creada);
    }

    // 200 OK + factura actualizada (404 si el id no existe)
    @PutMapping("/{id}")
    public ResponseEntity<FacturaReporteDTO> actualizar(@PathVariable Long id, @RequestBody FacturaRequestDTO dto) {
        return ResponseEntity.ok(service.actualizar(id, dto));
    }

        // 200 OK + factura con CAE (o RECHAZADA si ARCA la rechaza)
    @PostMapping("/{id}/informar")
    public ResponseEntity<FacturaReporteDTO> informar(@PathVariable Long id) {
        return ResponseEntity.ok(service.informarArca(id));
    }

        // 200 OK + PDF (409 si la factura todavia no tiene CAE)
    @GetMapping("/{id}/pdf")
    public ResponseEntity<byte[]> pdf(@PathVariable Long id) {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=factura-" + id + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfService.generar(id));
    }

    // 204 No Content (404 si el id no existe)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }

        // 200 OK + factura completa para editar (409 si esta informada o anulada, 404 si no existe)
    @GetMapping("/{id}")
    public FacturaEdicionDTO obtener(@PathVariable Long id) {
        return service.obtenerParaEdicion(id);
    }
}
