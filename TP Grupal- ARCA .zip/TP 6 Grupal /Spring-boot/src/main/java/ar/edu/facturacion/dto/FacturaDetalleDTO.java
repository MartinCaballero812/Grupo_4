package ar.edu.facturacion.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Renglon de una factura listo para cargarse en el formulario de edicion.
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaDetalleDTO {
    private Long listaPrecioArticuloId;
    private Long articuloId;          // id del Articulo (el stock es del articulo, no de la lista)
    private String descripcion;       // texto para mostrar: codigo - denominacion | marca | lista | precio
    private double cantidad;
    private double porcentajeBonificacion;
     private double precioVenta; 
}