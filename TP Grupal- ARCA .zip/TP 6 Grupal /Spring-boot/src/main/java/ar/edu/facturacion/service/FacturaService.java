package ar.edu.facturacion.service;



import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import ar.edu.facturacion.dto.FacturaDetalleDTO;
import ar.edu.facturacion.dto.FacturaEdicionDTO;

import ar.edu.facturacion.dto.ArticuloExplorerDTO;
import ar.edu.facturacion.dto.ClienteExplorerDTO;

import ar.edu.facturacion.arca.AfipWsaaClient;
import ar.edu.facturacion.arca.AfipWsfeClient;
import org.springframework.beans.factory.annotation.Value;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ar.edu.facturacion.model.Articulo;
import jakarta.persistence.LockModeType;


import ar.edu.facturacion.dto.CatalogosDTO;
import ar.edu.facturacion.dto.FacturaDetalleRequestDTO;
import ar.edu.facturacion.dto.FacturaReporteDTO;
import ar.edu.facturacion.dto.FacturaRequestDTO;
import ar.edu.facturacion.dto.OpcionCatalogoDTO;
import ar.edu.facturacion.exception.RecursoNoEncontradoException;
import ar.edu.facturacion.model.Cliente;
import ar.edu.facturacion.model.CondicionIva;
import ar.edu.facturacion.model.FacturaVenta;
import ar.edu.facturacion.model.FacturaVentaDetalle;
import ar.edu.facturacion.model.ListaPrecioArticulo;
import ar.edu.facturacion.model.PuntoVenta;
import ar.edu.facturacion.model.TipoMoneda;
import ar.edu.facturacion.model.Usuario;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;




import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class FacturaService {
    private static final double IVA = 0.21;
    private static final long USUARIO_SISTEMA_ID = 1L;
    private static final String ESTADO_INICIAL = "PENDIENTE";
    private static final String ESTADO_EMITIDA = "EMITIDA";
    private static final String ESTADO_RECHAZADA = "RECHAZADA";
    private static final String ESTADO_ANULADA = "ANULADA";
    private static final String LISTA_MAYORISTA = "MAYORISTA";
    private static final String LISTA_MINORISTA = "MINORISTA";
    private static final List<String> ESTADOS_VALIDOS =
            List.of(ESTADO_INICIAL, ESTADO_EMITIDA, ESTADO_RECHAZADA, ESTADO_ANULADA);

    private final EntityManager em;

        @Value("${arca.key-path}") private String arcaKeyPath;
    @Value("${arca.cert-path}") private String arcaCertPath;
    @Value("${arca.cuit}") private long arcaCuit;

    private static final int CBTE_TIPO_FACTURA_C = 11;
    private static final Pattern RESPUESTA_APROBADA =
            Pattern.compile("CAE: (\\d+) - Vencimiento CAE: (\\d{8})");

    // WSAA no entrega un ticket nuevo mientras el anterior siga vigente, por eso se guarda y se reutiliza.
    private String[] ticketArca;
    private long ticketArcaVence;

        private static final Path ARCHIVO_TICKET = Paths.get(System.getProperty("java.io.tmpdir"), "arca-wsfe-ticket.txt");

    
    public FacturaService(EntityManager em) {
        this.em = em;
    }

    // ---------- catalogos ----------

    @Transactional(readOnly = true)
    public CatalogosDTO obtenerCatalogos() {
        List<OpcionCatalogoDTO> clientes = consultarOpciones(
                "SELECT c.id, CONCAT(c.denominacion, ' - ', c.cuitCuil) FROM Cliente c ORDER BY c.denominacion");
        List<OpcionCatalogoDTO> condicionesIva = consultarOpciones(
                "SELECT c.id, c.denominacion FROM CondicionIva c ORDER BY c.denominacion");
        List<OpcionCatalogoDTO> monedas = consultarOpciones(
                "SELECT m.id, CONCAT(m.denominacion, ' (', m.simbolo, ')') FROM TipoMoneda m ORDER BY m.denominacion");

        List<Object[]> puntosVentaFilas = em.createQuery(
                "SELECT p.id, p.numero, p.descripcion FROM PuntoVenta p ORDER BY p.numero", Object[].class)
                .getResultList();
        List<OpcionCatalogoDTO> puntosVenta = puntosVentaFilas.stream()
                .map(fila -> new OpcionCatalogoDTO(
                        ((Number) fila[0]).longValue(),
                        "N° " + fila[1] + (fila[2] == null ? "" : " - " + fila[2])))
                .toList();

        List<Object[]> articulosFilas = em.createQuery(
                "SELECT lpa.id, a.codigo, a.denominacion, lp.denominacion, lpa.precioVenta "
                        + "FROM ListaPrecioArticulo lpa JOIN lpa.articulo a JOIN lpa.listaPrecio lp "
                        + "ORDER BY a.codigo, lp.denominacion",
                Object[].class)
                .getResultList();
        List<OpcionCatalogoDTO> articulos = articulosFilas.stream()
                .map(fila -> new OpcionCatalogoDTO(
                        ((Number) fila[0]).longValue(),
                        fila[1] + " - " + fila[2] + " | " + fila[3] + " | $ "
                                + String.format(Locale.ROOT, "%.2f", ((Number) fila[4]).doubleValue())))
                .toList();

        return new CatalogosDTO(clientes, condicionesIva, puntosVenta, monedas, articulos);
    }

    private List<OpcionCatalogoDTO> consultarOpciones(String jpql) {
        return em.createQuery(jpql, Object[].class).getResultList().stream()
                .map(fila -> new OpcionCatalogoDTO(((Number) fila[0]).longValue(), String.valueOf(fila[1])))
                .toList();
    }

    // ---------- busqueda con filtros y paginacion ----------

    // Agrega al WHERE los filtros informados (compartido por el listado y el conteo).
    private void aplicarFiltros(StringBuilder jpql, Map<String, Object> params,
                                Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo,
                                Long numeroFactura, Long clienteId, Boolean informada) {
        if (fechaDesde != null) {
            jpql.append("AND f.fechaEmision >= :fechaDesde ");
            params.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            // fechaHasta es inclusiva: se compara contra el inicio del dia siguiente
            jpql.append("AND f.fechaEmision < :fechaHasta ");
            params.put("fechaHasta", new Date(fechaHasta.getTime() + 24L * 60 * 60 * 1000));
        }
        if (estado != null && !estado.trim().isEmpty()) {
            jpql.append("AND f.estado = :estado ");
            params.put("estado", estado.trim().toUpperCase(Locale.ROOT));
        }
        if (montoMinimo != null) {
            jpql.append("AND f.importeTotal >= :montoMinimo ");
            params.put("montoMinimo", montoMinimo);
        }
        if (numeroFactura != null) {
            jpql.append("AND f.numero = :numeroFactura ");
            params.put("numeroFactura", numeroFactura);
        }
        if (clienteId != null) {
            jpql.append("AND f.cliente.id = :clienteId ");
            params.put("clienteId", clienteId);
        }
        if (informada != null) {
            // Informada a ARCA = tiene CAE
            if (informada) {
                jpql.append("AND f.cae IS NOT NULL AND f.cae <> '' ");
            } else {
                jpql.append("AND (f.cae IS NULL OR f.cae = '') ");
            }
        }
    }

    @Transactional(readOnly = true)
    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado,
                                                           Double montoMinimo, Long numeroFactura, Long clienteId,
                                                           Boolean informada, int page, int size) {
               StringBuilder jpql = new StringBuilder(
                "SELECT new ar.edu.facturacion.dto.FacturaReporteDTO("
                        + "   f.id, f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'), "
                        + "   ci.denominacion, pv.descripcion, f.estado, f.importeTotal, COUNT(d), f.cae, "
                        + "   tm.denominacion, f.observaciones, f.motivoRechazo"
                        + ") "
                        + "FROM FacturaVenta f "
                        + "LEFT JOIN f.cliente c "
                        + "JOIN f.condicionIva ci "
                        + "JOIN f.puntoVenta pv "
                        + "JOIN f.tipoMoneda tm "
                        + "JOIN f.detalles d "
                        + "WHERE 1=1 ");
        Map<String, Object> params = new HashMap<>();
        aplicarFiltros(jpql, params, fechaDesde, fechaHasta, estado, montoMinimo, numeroFactura, clienteId, informada);
                             jpql.append("GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion, "
                + "pv.descripcion, f.estado, f.importeTotal, f.cae, tm.denominacion, "
                + "f.observaciones, f.motivoRechazo ");
        jpql.append("ORDER BY f.numero DESC");

        TypedQuery<FacturaReporteDTO> q = em.createQuery(jpql.toString(), FacturaReporteDTO.class);
        params.forEach(q::setParameter);
        q.setFirstResult(page * size);
        q.setMaxResults(size);
        return q.getResultList();
    }

    @Transactional(readOnly = true)
    public long contarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo,
                                        Long numeroFactura, Long clienteId, Boolean informada) {
        StringBuilder jpql = new StringBuilder("SELECT COUNT(f) FROM FacturaVenta f WHERE 1=1 ");
        Map<String, Object> params = new HashMap<>();
        aplicarFiltros(jpql, params, fechaDesde, fechaHasta, estado, montoMinimo, numeroFactura, clienteId, informada);

        TypedQuery<Long> q = em.createQuery(jpql.toString(), Long.class);
        params.forEach(q::setParameter);
        return q.getSingleResult();
    }

    // ---------- alta / modificacion / baja ----------

    // Crea la factura con sus detalles. Todo en una sola transaccion: si algo falla, no se guarda nada.
    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO dto) {
        validarCabeceraAlta(dto);
        validarDetalles(dto.getDetalles());

        Usuario usuario = buscarPorId(Usuario.class, USUARIO_SISTEMA_ID, "Usuario del sistema");
        Date ahora = new Date();

        FacturaVenta factura = new FacturaVenta();
        // Campos obligatorios heredados de AuditoriaApp
        factura.setFechaAlta(ahora);
        factura.setFechaModificacion(ahora);
        factura.setUsuarioCarga(usuario);
        factura.setUsuarioModificacion(usuario);
        // Cabecera: relaciones buscadas por id (404 si alguna no existe)
        factura.setPuntoVenta(buscarPorId(PuntoVenta.class, dto.getPuntoVentaId(), "Punto de venta"));
        factura.setCondicionIva(buscarPorId(CondicionIva.class, dto.getCondicionIvaId(), "Condicion de IVA"));
        factura.setTipoMoneda(buscarPorId(TipoMoneda.class, dto.getTipoMonedaId(), "Tipo de moneda"));
        if (Boolean.TRUE.equals(dto.getSinCliente())) {
            factura.setCliente(null); // pasa a Consumidor Final
        } else if (dto.getClienteId() != null) {
            factura.setCliente(buscarPorId(Cliente.class, dto.getClienteId(), "Cliente"));
        }
        factura.setFechaEmision(ahora);
        // Numero correlativo unico en todo el sistema (ultimo + 1).
        factura.setNumero(proximoNumero());
        factura.setEstado(ESTADO_INICIAL);
        factura.setObservaciones(dto.getObservaciones());
        // Detalles + importes (neto, IVA, total)
 

        cargarDetalles(factura, dto.getDetalles());

        em.persist(factura); // cascade = ALL: persiste tambien los detalles
        return aReporteDTO(factura);
    }

    // Actualiza cabecera, estado y/o items. Solo se modifica lo que venga informado en el DTO.
  
    @Transactional
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO dto) {
        if (dto == null) {
            throw new IllegalArgumentException("Falta el cuerpo de la peticion");
        }
        FacturaVenta factura = buscarFactura(id);
        if (ESTADO_ANULADA.equals(factura.getEstado())) {
            throw new IllegalStateException("La factura " + factura.getNumero() + " esta ANULADA y no puede modificarse");
        }
        if (factura.getCae() != null && !factura.getCae().trim().isEmpty()) {
            // Ya informada a ARCA: se bloquea la modificacion, solo se permite pasar a ANULADA
            boolean tocaDatos = dto.getPuntoVentaId() != null || dto.getCondicionIvaId() != null
                    || dto.getTipoMonedaId() != null || dto.getClienteId() != null
                    || dto.getObservaciones() != null || dto.getDetalles() != null;
            boolean pideAnular = dto.getEstado() != null && dto.getEstado().trim().equalsIgnoreCase(ESTADO_ANULADA);
            if (tocaDatos || !pideAnular) {
                throw new IllegalStateException("La factura " + factura.getNumero()
                        + " ya fue informada a ARCA y no puede modificarse, solo anularse");
            }
        }
        if (dto.getPuntoVentaId() != null) {
            factura.setPuntoVenta(buscarPorId(PuntoVenta.class, dto.getPuntoVentaId(), "Punto de venta"));
        }
        if (dto.getCondicionIvaId() != null) {
            factura.setCondicionIva(buscarPorId(CondicionIva.class, dto.getCondicionIvaId(), "Condicion de IVA"));
        }
        if (dto.getTipoMonedaId() != null) {
            factura.setTipoMoneda(buscarPorId(TipoMoneda.class, dto.getTipoMonedaId(), "Tipo de moneda"));
        }
        if (dto.getClienteId() != null) {
            factura.setCliente(buscarPorId(Cliente.class, dto.getClienteId(), "Cliente"));
        }
        if (dto.getObservaciones() != null) {
            factura.setObservaciones(dto.getObservaciones());
        }
        if (dto.getDetalles() != null) {
            validarDetalles(dto.getDetalles());
            devolverStock(factura);                      // se devuelve lo que tenia reservado
            factura.getDetalles().clear();               // orphanRemoval = true: borra los renglones viejos
            cargarDetalles(factura, dto.getDetalles());  // descuenta el stock nuevo y recalcula importes
        }
        if (dto.getEstado() != null && !dto.getEstado().trim().isEmpty()) {
            String estado = dto.getEstado().trim().toUpperCase(Locale.ROOT);
            if (!ESTADOS_VALIDOS.contains(estado)) {
                throw new IllegalArgumentException("Estado invalido: " + estado + ". Valores permitidos: " + ESTADOS_VALIDOS);
            }
            factura.setEstado(estado);
            if (ESTADO_ANULADA.equals(estado)) {
                devolverStock(factura);                  // anulacion: las unidades vuelven al stock
                factura.setFechaAnulacion(new Date());   // anulacion logica
                if (dto.getMotivo() != null && !dto.getMotivo().trim().isEmpty()) {
                    String motivo = dto.getMotivo().trim();
                    factura.setMotivoRechazo(motivo.length() > 255 ? motivo.substring(0, 255) : motivo);
                }
            }
        }

        factura.setFechaModificacion(new Date());
        factura.setUsuarioModificacion(buscarPorId(Usuario.class, USUARIO_SISTEMA_ID, "Usuario del sistema"));
        return aReporteDTO(factura);
    }

    // Eliminacion fisica (los detalles se borran en cascada). Una factura con CAE ya fue autorizada por ARCA:
    // esa no se elimina, se anula (PUT con estado ANULADA).
    @Transactional
    public void eliminar(Long id) {
        FacturaVenta factura = buscarFactura(id);
        if (factura.getCae() != null && !factura.getCae().trim().isEmpty()) {
            throw new IllegalStateException("La factura " + factura.getNumero() + " tiene CAE y no puede eliminarse; debe anularse");
        }
        if (!ESTADO_ANULADA.equals(factura.getEstado())) {
            devolverStock(factura); // si estaba anulada, el stock ya se habia devuelto
        }
        em.remove(factura);
    }
        // ---------- informar a ARCA ----------

       private synchronized String[] ticketArca() throws Exception {
        long ahora = System.currentTimeMillis();
        if (ticketArca == null || ahora > ticketArcaVence) {
            leerTicketGuardado(ahora); // despues de un reinicio, recupera el ticket que sigue vigente
        }
        if (ticketArca == null || ahora > ticketArcaVence) {
            ticketArca = AfipWsaaClient.obtenerTokenYSign(arcaKeyPath, arcaCertPath, "wsfe");
            ticketArcaVence = ahora + 11L * 60 * 60 * 1000; // el ticket dura 12 hs
            Files.write(ARCHIVO_TICKET, List.of(ticketArca[0], ticketArca[1], String.valueOf(ticketArcaVence)));
        }
        return ticketArca;
    }

    private void leerTicketGuardado(long ahora) {
        try {
            if (Files.exists(ARCHIVO_TICKET)) {
                List<String> lineas = Files.readAllLines(ARCHIVO_TICKET);
                if (lineas.size() >= 3 && ahora < Long.parseLong(lineas.get(2).trim())) {
                    ticketArca = new String[]{lineas.get(0), lineas.get(1)};
                    ticketArcaVence = Long.parseLong(lineas.get(2).trim());
                }
            }
        } catch (Exception e) {
            // archivo ilegible: se pide un ticket nuevo
        }
    }

    @Transactional
    public FacturaReporteDTO informarArca(Long id) {
        FacturaVenta f = buscarFactura(id);
        if (ESTADO_ANULADA.equals(f.getEstado())) {
            throw new IllegalStateException("La factura " + f.getNumero() + " esta ANULADA y no puede informarse");
        }
        if (f.getCae() != null && !f.getCae().trim().isEmpty()) {
            throw new IllegalStateException("La factura " + f.getNumero() + " ya fue informada a ARCA");
        }

        String resultado;
        try {
            String[] t = ticketArca();
            int pv = f.getPuntoVenta().getNumero();
            int nro = AfipWsfeClient.obtenerUltimoComprobante(t[0], t[1], arcaCuit, pv, CBTE_TIPO_FACTURA_C) + 1;
            resultado = AfipWsfeClient.solicitarCae(t[0], t[1], arcaCuit, pv, CBTE_TIPO_FACTURA_C, nro, f.getImporteTotal());
        } catch (Exception e) {
            throw new IllegalStateException("No se pudo comunicar con ARCA: " + e.getMessage());
        }

        Matcher m = RESPUESTA_APROBADA.matcher(resultado);
        if (m.find()) {
            f.setCae(m.group(1));
            f.setCaeFechaVencimiento(Date.from(LocalDate.parse(m.group(2), DateTimeFormatter.BASIC_ISO_DATE)
                    .atStartOfDay(ZoneId.of("America/Argentina/Buenos_Aires")).toInstant()));
            f.setEstado(ESTADO_EMITIDA);
            f.setResultadoAfip("A");
            f.setMotivoRechazo(null);
        } else {
            f.setEstado(ESTADO_RECHAZADA);
            f.setResultadoAfip("R");
            f.setMotivoRechazo(resultado.length() > 255 ? resultado.substring(0, 255) : resultado);
        }
        f.setFechaModificacion(new Date());
        return aReporteDTO(f);
    }

        // ---------- explorers (ventanas modales de busqueda) ----------

    @Transactional(readOnly = true)
    public Map<String, Object> explorarClientes(String texto, int page, int size) {
        String t = "%" + (texto == null ? "" : texto.trim().toLowerCase(Locale.ROOT)) + "%";
        String where = "WHERE LOWER(c.denominacion) LIKE :t OR c.cuitCuil LIKE :t ";
        List<ClienteExplorerDTO> items = em.createQuery(
                "SELECT new ar.edu.facturacion.dto.ClienteExplorerDTO(c.id, c.denominacion, c.cuitCuil) "
                        + "FROM Cliente c " + where + "ORDER BY c.denominacion", ClienteExplorerDTO.class)
                .setParameter("t", t).setFirstResult(page * size).setMaxResults(size).getResultList();
        long total = em.createQuery("SELECT COUNT(c) FROM Cliente c " + where, Long.class)
                .setParameter("t", t).getSingleResult();
        return pagina(items, total, page, size);
    }

     @Transactional(readOnly = true)
    public Map<String, Object> explorarArticulos(String texto, String lista, int page, int size) {
        String codigoLista = lista == null ? LISTA_MINORISTA : lista.trim().toUpperCase(Locale.ROOT);
        if (!LISTA_MINORISTA.equals(codigoLista) && !LISTA_MAYORISTA.equals(codigoLista)) {
            throw new IllegalArgumentException("Lista de precios invalida: " + lista
                    + ". Valores permitidos: " + LISTA_MINORISTA + ", " + LISTA_MAYORISTA);
        }
        String t = "%" + (texto == null ? "" : texto.trim().toLowerCase(Locale.ROOT)) + "%";
        String from = "FROM ListaPrecioArticulo lpa JOIN lpa.articulo a JOIN lpa.listaPrecio lp "
                + "LEFT JOIN a.marca m LEFT JOIN a.rubro r ";
        String where = "WHERE lp.codigo = :lista AND (LOWER(a.codigo) LIKE :t OR LOWER(a.denominacion) LIKE :t) ";

        List<Object[]> filas = em.createQuery(
                "SELECT lpa.id, a.codigo, a.denominacion, lp.denominacion, lpa.precioVenta, a.stock, a.id, "
                        + "COALESCE(m.denominacion, 'Sin marca'), COALESCE(r.denominacion, 'Sin rubro') "
                        + from + where + "ORDER BY a.codigo", Object[].class)
                .setParameter("lista", codigoLista).setParameter("t", t)
                .setFirstResult(page * size).setMaxResults(size).getResultList();

        List<ArticuloExplorerDTO> items = filas.stream().map(f -> {
            double stock = ((Number) f[5]).doubleValue();
            double minima = 1;
            boolean disponible = stock >= minima;
            String disponibilidad = stock <= 0 ? "Sin stock"
                    : disponible ? "Disponible"
                    : "Stock insuficiente";
            return new ArticuloExplorerDTO(((Number) f[0]).longValue(), ((Number) f[6]).longValue(),
                    (String) f[1], (String) f[2], (String) f[8], (String) f[7], (String) f[3],
                    ((Number) f[4]).doubleValue(), stock, minima, disponible, disponibilidad);
        }).toList();

        long total = em.createQuery("SELECT COUNT(lpa) " + from + where, Long.class)
                .setParameter("lista", codigoLista).setParameter("t", t).getSingleResult();
        return pagina(items, total, page, size);
    }
    private Map<String, Object> pagina(List<?> items, long total, int page, int size) {
        Map<String, Object> r = new HashMap<>();
        r.put("items", items);
        r.put("total", total);
        r.put("page", page);
        r.put("size", size);
        return r;
    }
    // Datos de una factura para cargarla en el formulario de edicion. Si esta informada (CAE) o anulada, no se edita.
    @Transactional(readOnly = true)
    public FacturaEdicionDTO obtenerParaEdicion(Long id) {
        FacturaVenta f = buscarFactura(id);
        if (ESTADO_ANULADA.equals(f.getEstado())) {
            throw new IllegalStateException("La factura " + f.getNumero() + " esta ANULADA y no puede modificarse");
        }
        if (f.getCae() != null && !f.getCae().trim().isEmpty()) {
            throw new IllegalStateException("La factura " + f.getNumero()
                    + " ya fue informada a ARCA y no puede modificarse, solo anularse");
        }
        Locale ar = new Locale("es", "AR");
        List<FacturaDetalleDTO> detalles = f.getDetalles().stream().map(d -> {
            ListaPrecioArticulo lpa = d.getListaPrecioArticulo();
            Articulo a = lpa.getArticulo();
            String marca = a.getMarca() != null ? a.getMarca().getDenominacion() : "Sin marca";
            String texto = a.getCodigo() + " - " + a.getDenominacion() + " | " + marca + " | "
                    + lpa.getListaPrecio().getDenominacion() + " | $ " + String.format(ar, "%,.2f", lpa.getPrecioVenta());
                        return new FacturaDetalleDTO(lpa.getId(), a.getId(), texto, d.getCantidad(), d.getPorcentajeBonificacion(), lpa.getPrecioVenta());
        }).toList();
        Cliente c = f.getCliente();
        return new FacturaEdicionDTO(f.getId(), f.getNumero(), f.getEstado(),
                c != null ? c.getId() : null,
                c != null ? c.getDenominacion() + " - " + c.getCuitCuil() : null,
                f.getCondicionIva().getId(), f.getPuntoVenta().getId(), f.getTipoMoneda().getId(),
                f.getObservaciones(), detalles);
    }
    // ---------- auxiliares ----------

    private FacturaVenta buscarFactura(Long id) {
        return buscarPorId(FacturaVenta.class, id, "Factura");
    }

    private <T> T buscarPorId(Class<T> clase, Long id, String nombre) {
        T entidad = em.find(clase, id);
        if (entidad == null) {
            throw new RecursoNoEncontradoException(nombre + " con id " + id + " no existe");
        }
        return entidad;
    }

    private void validarCabeceraAlta(FacturaRequestDTO dto) {
        if (dto == null) {
            throw new IllegalArgumentException("Falta el cuerpo de la peticion");
        }
        if (dto.getPuntoVentaId() == null) { throw new IllegalArgumentException("puntoVentaId es obligatorio"); }
        if (dto.getCondicionIvaId() == null) { throw new IllegalArgumentException("condicionIvaId es obligatorio"); }
        if (dto.getTipoMonedaId() == null) { throw new IllegalArgumentException("tipoMonedaId es obligatorio"); }
    }

    private void validarDetalles(List<FacturaDetalleRequestDTO> detalles) {
        if (detalles == null || detalles.isEmpty()) {
            throw new IllegalArgumentException("La factura debe tener al menos un detalle");
        }
        for (FacturaDetalleRequestDTO d : detalles) {
            if (d == null || d.getArticuloId() == null) {
                throw new IllegalArgumentException("Cada detalle debe indicar articuloId");
            }
            if (d.getCantidad() == null || d.getCantidad() <= 0) {
                throw new IllegalArgumentException("La cantidad del articulo " + d.getArticuloId() + " debe ser mayor a 0");
            }
            if (d.getCantidad() % 1 != 0) {
                throw new IllegalArgumentException("La cantidad del articulo " + d.getArticuloId() + " debe ser un numero entero");
            }
            if (d.getPorcentajeBonificacion() != null
                    && (d.getPorcentajeBonificacion() < 0 || d.getPorcentajeBonificacion() > 100)) {
                throw new IllegalArgumentException("La bonificacion del articulo " + d.getArticuloId() + " debe estar entre 0 y 100");
            }
        }
    }

    // Arma cada FacturaVentaDetalle y calcula los importes con la misma formula que DatosEjemplo:
    // subtotal = cantidad * precio; neto = subtotal - bonificacion; iva = neto * 21%; total = suma(neto + iva).
    private void cargarDetalles(FacturaVenta factura, List<FacturaDetalleRequestDTO> items) {
        double total = 0;
        for (FacturaDetalleRequestDTO item : items) {
            ListaPrecioArticulo lpa =
                    buscarPorId(ListaPrecioArticulo.class, item.getArticuloId(), "Articulo");
            Articulo articulo = bloquearArticulo(lpa.getArticulo().getId());
            validarStock(lpa, articulo, item.getCantidad());
            articulo.setStock(articulo.getStock() - item.getCantidad()); // la venta descuenta stock
            double bonificacion = item.getPorcentajeBonificacion() == null ? 0 : item.getPorcentajeBonificacion();
            double precio = lpa.getPrecioVenta();
            double subtotal = redondear(item.getCantidad() * precio);
            double neto = redondear(subtotal * (1 - bonificacion / 100.0));
            double iva = redondear(neto * IVA);

            FacturaVentaDetalle detalle = new FacturaVentaDetalle();
            detalle.setListaPrecioArticulo(lpa);
            detalle.setDescripcion(item.getDescripcion() != null && !item.getDescripcion().trim().isEmpty()
                    ? item.getDescripcion().trim() : lpa.getArticulo().getDenominacion());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(precio);
            detalle.setImporteSubtotal(subtotal);
            detalle.setPorcentajeBonificacion(bonificacion);
            detalle.setImporteNeto(neto);
            detalle.setImporteIva(iva);
            factura.agregarDetalle(detalle); // agrega a la lista y setea detalle.factura
            total += neto + iva;
        }
        factura.setImporteTotal(redondear(total));
        factura.setImporteSaldo(redondear(factura.getImporteTotal() - factura.getImporteCobrado()));
    }

    // Numero correlativo unico (ultimo + 1).
    private Long proximoNumero() {
        Long maximo = em.createQuery("SELECT MAX(f.numero) FROM FacturaVenta f", Long.class)
                .getSingleResult();
        return (maximo == null ? 0L : maximo) + 1;
    }

    private double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
    private FacturaReporteDTO aReporteDTO(FacturaVenta f) {
        return new FacturaReporteDTO(
                f.getId(), f.getNumero(), f.getFechaEmision(),
                f.getCliente() != null ? f.getCliente().getDenominacion() : "Consumidor Final",
                f.getCondicionIva().getDenominacion(), f.getPuntoVenta().getDescripcion(),
                f.getEstado(), f.getImporteTotal(), f.getDetalles().size(), f.getCae(),
                f.getTipoMoneda().getDenominacion(), f.getObservaciones(), f.getMotivoRechazo());
    }


        // Bloquea la fila del articulo hasta el fin de la transaccion: dos ventas simultaneas no pueden pisarse el stock.
    private Articulo bloquearArticulo(Long id) {
        Articulo articulo = em.find(Articulo.class, id, LockModeType.PESSIMISTIC_WRITE);
        if (articulo == null) {
            throw new RecursoNoEncontradoException("Articulo con id " + id + " no existe");
        }
        return articulo;
    }

    private void validarStock(ListaPrecioArticulo lpa, Articulo articulo, double cantidad) {
        String nombre = articulo.getDenominacion();
        if (articulo.getStock() <= 0) {
            throw new IllegalStateException("Sin stock de " + nombre);
        }
        if (cantidad > articulo.getStock()) {
            throw new IllegalStateException("Stock insuficiente de " + nombre
                    + ": disponible " + (long) articulo.getStock() + ", pedido " + (long) cantidad);
        }
    }

    private void devolverStock(FacturaVenta factura) {
        for (FacturaVentaDetalle d : factura.getDetalles()) {
            Articulo articulo = bloquearArticulo(d.getListaPrecioArticulo().getArticulo().getId());
            articulo.setStock(articulo.getStock() + d.getCantidad());
        }
    }
}