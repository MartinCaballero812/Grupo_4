package ar.edu.facturacion.arca;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class AfipWsfeClient {

    private static final String URL_WSFE_HOMO = "https://wswhomo.afip.gov.ar/wsfev1/service.asmx";
    private static final String NS = "http://ar.gov.afip.dif.FEV1/";

    // FECompUltimoAutorizado: devuelve el ultimo numero de comprobante autorizado
    public static int obtenerUltimoComprobante(String token, String sign, long cuit, int ptoVta, int cbteTipo) throws Exception {
        String xml = sobre("<FECompUltimoAutorizado xmlns=\"" + NS + "\">" + auth(token, sign, cuit)
                + "<PtoVta>" + ptoVta + "</PtoVta><CbteTipo>" + cbteTipo + "</CbteTipo></FECompUltimoAutorizado>");
        String resp = enviarSoap(NS + "FECompUltimoAutorizado", xml);
        String nro = tag(resp, "CbteNro");
        if (nro == null) throw new RuntimeException("ARCA no devolvio CbteNro. Respuesta: " + resp);
        return Integer.parseInt(nro);
    }

    // FECAESolicitar: pide el CAE para una Factura C a Consumidor Final. Devuelve un resumen del resultado.
    public static String solicitarCae(String token, String sign, long cuit, int ptoVta, int cbteTipo,
                                      int nroComprobante, double importe) throws Exception {
        String fecha = LocalDate.now(ZoneId.of("America/Argentina/Buenos_Aires")).format(DateTimeFormatter.BASIC_ISO_DATE);
        String total = String.format(Locale.US, "%.2f", importe);

        // El orden de los elementos lo define el WSDL de ARCA: no cambiarlo.
        String xml = sobre("<FECAESolicitar xmlns=\"" + NS + "\">" + auth(token, sign, cuit)
                + "<FeCAEReq>"
                + "<FeCabReq><CantReg>1</CantReg><PtoVta>" + ptoVta + "</PtoVta><CbteTipo>" + cbteTipo + "</CbteTipo></FeCabReq>"
                + "<FeDetReq><FECAEDetRequest>"
                + "<Concepto>1</Concepto>"                       // 1 = Productos
                + "<DocTipo>99</DocTipo><DocNro>0</DocNro>"      // 99 = Consumidor Final
                + "<CbteDesde>" + nroComprobante + "</CbteDesde><CbteHasta>" + nroComprobante + "</CbteHasta>"
                + "<CbteFch>" + fecha + "</CbteFch>"
                + "<ImpTotal>" + total + "</ImpTotal><ImpTotConc>0.00</ImpTotConc><ImpNeto>" + total + "</ImpNeto>"
                + "<ImpOpEx>0.00</ImpOpEx><ImpTrib>0.00</ImpTrib><ImpIVA>0.00</ImpIVA>"   // Factura C no discrimina IVA
                + "<MonId>PES</MonId><MonCotiz>1</MonCotiz>"
                + "<CondicionIVAReceptorId>5</CondicionIVAReceptorId>"                    // 5 = Consumidor Final
                + "</FECAEDetRequest></FeDetReq></FeCAEReq></FECAESolicitar>");

        String resp = enviarSoap(NS + "FECAESolicitar", xml);

        // Se toma el resultado del detalle (el comprobante), no el de la cabecera.
        String detalle = resp.contains("<FECAEDetResponse>")
                ? resp.substring(resp.indexOf("<FECAEDetResponse>"), resp.indexOf("</FECAEDetResponse>")) : "";
        if ("A".equals(tag(detalle, "Resultado"))) {
            return "APROBADA - CAE: " + tag(detalle, "CAE") + " - Vencimiento CAE: " + tag(detalle, "CAEFchVto");
        }
        // Rechazo: se muestran observaciones y errores que informa ARCA
        StringBuilder motivo = new StringBuilder("RECHAZADA por ARCA.");
        for (String bloque : new String[]{"Obs", "Err"}) {
            String resto = resp;
            while (resto.contains("<" + bloque + ">")) {
                String item = resto.substring(resto.indexOf("<" + bloque + ">"), resto.indexOf("</" + bloque + ">"));
                motivo.append(" [").append(tag(item, "Code")).append("] ").append(tag(item, "Msg"));
                resto = resto.substring(resto.indexOf("</" + bloque + ">") + bloque.length() + 3);
            }
        }
        return motivo.toString();
    }

    private static String auth(String token, String sign, long cuit) {
        return "<Auth><Token>" + token + "</Token><Sign>" + sign + "</Sign><Cuit>" + cuit + "</Cuit></Auth>";
    }

    private static String sobre(String cuerpo) {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"><soap:Body>"
                + cuerpo + "</soap:Body></soap:Envelope>";
    }

    // Texto del primer <nombre>...</nombre>, o null si no esta
    private static String tag(String xml, String nombre) {
        int i = xml.indexOf("<" + nombre + ">");
        if (i < 0) return null;
        int fin = xml.indexOf("</" + nombre + ">", i);
        return xml.substring(i + nombre.length() + 2, fin).trim();
    }

    private static String enviarSoap(String soapAction, String xml) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(URL_WSFE_HOMO))
                .header("Content-Type", "text/xml; charset=utf-8")
                .header("SOAPAction", "\"" + soapAction + "\"")
                .POST(HttpRequest.BodyPublishers.ofString(xml, StandardCharsets.UTF_8)).build();
        HttpResponse<String> resp = HttpClient.newHttpClient().send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (resp.statusCode() >= 400) {
            throw new RuntimeException("WSFE respondio HTTP " + resp.statusCode() + ": " + resp.body());
        }
        return resp.body();
    }
}