package ar.edu.facturacion.dto;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// DTO resumido para reporte ejecutivo de ventas (proyeccion JPQL directa).
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class FacturaReporteDTO {
    private Long id;
    private Long numeroFactura;
    private Date fechaEmision;
    private String clienteDenominacion;
    private String condicionIva;
    private String puntoVentaDescripcion;
    private String estado;
    private double importeTotal;
    private long cantidadItems;
    private String cae;
    private String moneda;
    private String observaciones;
    private String motivo;
}