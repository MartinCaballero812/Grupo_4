package ar.edu.facturacion.dto;

public record ClienteExplorerDTO(Long id, String denominacion, String cuitCuil) {
}