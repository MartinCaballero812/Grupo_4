package ar.edu.facturacion.dto;

public record ArticuloExplorerDTO(Long id, Long articuloId, String codigo, String articulo, String rubro, String marca,
                                  String listaPrecio, double precioVenta, double stock, double cantidadMinima,
                                  boolean disponible, String disponibilidad) {
}