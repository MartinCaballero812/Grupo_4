package ar.edu.facturacion.arca;

import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;

import java.io.FileInputStream;
import java.io.FileReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.Collections;

public class AfipWsaaClient {

    private static final String URL_WSAA_HOMO = "https://wsaahomo.afip.gov.ar/ws/services/LoginCms";

    // Devuelve {token, sign}
    public static String[] obtenerTokenYSign(String keyPath, String certPath, String servicio) throws Exception {
        Provider bc = new BouncyCastleProvider();
        PrivateKey privateKey = cargarClavePrivada(keyPath);
        X509Certificate cert = cargarCertificado(certPath);

        // 1) Pedido de ticket (TRA)
        ZonedDateTime ahora = ZonedDateTime.now(ZoneId.of("America/Argentina/Buenos_Aires")).truncatedTo(ChronoUnit.SECONDS);
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX");
        String traXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<loginTicketRequest version=\"1.0\"><header>"
                + "<uniqueId>" + (System.currentTimeMillis() / 1000) + "</uniqueId>"
                + "<generationTime>" + ahora.minusMinutes(10).format(fmt) + "</generationTime>"
                + "<expirationTime>" + ahora.plusMinutes(10).format(fmt) + "</expirationTime>"
                + "</header><service>" + servicio + "</service></loginTicketRequest>";

        // 2) Firma CMS / PKCS#7
        ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").setProvider(bc).build(privateKey);
        CMSSignedDataGenerator gen = new CMSSignedDataGenerator();
        gen.addSignerInfoGenerator(new JcaSignerInfoGeneratorBuilder(
                new JcaDigestCalculatorProviderBuilder().setProvider(bc).build()).build(signer, cert));
        gen.addCertificates(new JcaCertStore(Collections.singletonList(cert)));
        CMSSignedData signedData = gen.generate(new CMSProcessableByteArray(traXml.getBytes(StandardCharsets.UTF_8)), true);
        String cmsBase64 = Base64.getEncoder().encodeToString(signedData.getEncoded());

        // 3) Llamada SOAP a WSAA
        String soap = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\""
                + " xmlns:wsaa=\"http://wsaa.view.sua.dvadac.desein.afip.gov\">"
                + "<soapenv:Header/><soapenv:Body><wsaa:loginCms><wsaa:in0>" + cmsBase64
                + "</wsaa:in0></wsaa:loginCms></soapenv:Body></soapenv:Envelope>";
        String respuesta = enviarSoap(URL_WSAA_HOMO, "", soap);

        // 4) La respuesta trae otro XML escapado dentro de <loginCmsReturn>
        String xml = respuesta.replace("&lt;", "<").replace("&gt;", ">");
        if (!xml.contains("<token>")) {
            throw new RuntimeException("WSAA no devolvio token. Respuesta: " + respuesta);
        }
        String token = xml.substring(xml.indexOf("<token>") + 7, xml.indexOf("</token>"));
        String sign = xml.substring(xml.indexOf("<sign>") + 6, xml.indexOf("</sign>"));
        return new String[]{token, sign};
    }

    // Acepta clave "BEGIN RSA PRIVATE KEY" y "BEGIN PRIVATE KEY"
    private static PrivateKey cargarClavePrivada(String path) throws Exception {
        try (PEMParser parser = new PEMParser(new FileReader(path))) {
            Object obj = parser.readObject();
            JcaPEMKeyConverter conv = new JcaPEMKeyConverter();
            if (obj instanceof PEMKeyPair) return conv.getKeyPair((PEMKeyPair) obj).getPrivate();
            return conv.getPrivateKey((PrivateKeyInfo) obj);
        }
    }

    private static X509Certificate cargarCertificado(String path) throws Exception {
        try (FileInputStream fis = new FileInputStream(path)) {
            return (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(fis);
        }
    }

    private static String enviarSoap(String url, String soapAction, String xml) throws Exception {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .header("Content-Type", "text/xml; charset=utf-8")
                .header("SOAPAction", "\"" + soapAction + "\"")
                .POST(HttpRequest.BodyPublishers.ofString(xml, StandardCharsets.UTF_8)).build();
        HttpResponse<String> resp = HttpClient.newHttpClient().send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (resp.statusCode() >= 400) {
            throw new RuntimeException("WSAA respondio HTTP " + resp.statusCode() + ": " + resp.body());
        }
        return resp.body();
    }
}