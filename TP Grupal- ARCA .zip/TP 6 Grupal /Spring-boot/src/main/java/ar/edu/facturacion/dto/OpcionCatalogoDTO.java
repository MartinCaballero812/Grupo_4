package ar.edu.facturacion.dto;

public record OpcionCatalogoDTO(Long id, String descripcion) {
}