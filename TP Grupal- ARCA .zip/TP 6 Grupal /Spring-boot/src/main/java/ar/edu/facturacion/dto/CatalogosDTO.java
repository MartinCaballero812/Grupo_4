package ar.edu.facturacion.dto;

import java.util.List;

public record CatalogosDTO(
        List<OpcionCatalogoDTO> clientes,
        List<OpcionCatalogoDTO> condicionesIva,
        List<OpcionCatalogoDTO> puntosVenta,
        List<OpcionCatalogoDTO> monedas,
        List<OpcionCatalogoDTO> articulos) {
}