package ar.edu.facturacion.service;

import ar.edu.facturacion.exception.RecursoNoEncontradoException;
import ar.edu.facturacion.model.FacturaVenta;
import ar.edu.facturacion.model.FacturaVentaDetalle;
import com.itextpdf.barcodes.BarcodeQRCode;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Locale;

@Service
public class FacturaPdfService {
    private static final Locale AR = new Locale("es", "AR");
    private static final int CBTE_TIPO_FACTURA_C = 11;

    @Value("${arca.cuit}")
    private long cuitEmisor;

    private final EntityManager em;

    public FacturaPdfService(EntityManager em) {
        this.em = em;
    }

    @Transactional(readOnly = true)
    public byte[] generar(Long id) {
        FacturaVenta f = em.find(FacturaVenta.class, id);
        if (f == null) {
            throw new RecursoNoEncontradoException("Factura con id " + id + " no existe");
        }
        if (f.getCae() == null || f.getCae().trim().isEmpty()) {
            throw new IllegalStateException("La factura " + f.getNumero() + " todavia no fue informada a ARCA");
        }

        SimpleDateFormat fecha = new SimpleDateFormat("dd/MM/yyyy");
        String simbolo = f.getTipoMoneda().getSimbolo();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfDocument pdf = new PdfDocument(new PdfWriter(out));

        try (Document doc = new Document(pdf)) {
            doc.add(new Paragraph("FACTURA C").setBold().setFontSize(20));
            doc.add(new Paragraph(String.format("N° %05d-%08d", f.getPuntoVenta().getNumero(), f.getNumero())));
            doc.add(new Paragraph("Fecha de emisión: " + fecha.format(f.getFechaEmision())));
            doc.add(new Paragraph("Punto de venta: " + f.getPuntoVenta().getDescripcion()));
            doc.add(new Paragraph("Cliente: " + (f.getCliente() != null
                    ? f.getCliente().getDenominacion() + " - CUIT/CUIL " + f.getCliente().getCuitCuil()
                    : "Consumidor Final")));
            doc.add(new Paragraph("Condición de IVA: " + f.getCondicionIva().getDenominacion()));

            Table tabla = new Table(UnitValue.createPercentArray(new float[]{45, 10, 15, 10, 20})).useAllAvailableWidth();
            for (String titulo : new String[]{"Descripción", "Cant.", "Precio unit.", "Bonif. %", "Importe"}) {
                tabla.addHeaderCell(new Cell().add(new Paragraph(titulo).setBold()));
            }
            for (FacturaVentaDetalle d : f.getDetalles()) {
                tabla.addCell(new Cell().add(new Paragraph(d.getDescripcion())));
                tabla.addCell(derecha(String.format(AR, "%.0f", d.getCantidad())));
                tabla.addCell(derecha(String.format(AR, "%,.2f", d.getPrecioUnitario())));
                tabla.addCell(derecha(String.format(AR, "%.2f", d.getPorcentajeBonificacion())));
                tabla.addCell(derecha(String.format(AR, "%,.2f", d.getImporteNeto() + d.getImporteIva())));
            }
            doc.add(tabla.setMarginTop(15));

            doc.add(new Paragraph("TOTAL: " + simbolo + " " + String.format(AR, "%,.2f", f.getImporteTotal()))
                    .setBold().setFontSize(14).setTextAlignment(TextAlignment.RIGHT));

            doc.add(new Paragraph("CAE N°: " + f.getCae()).setMarginTop(20));
            doc.add(new Paragraph("Fecha de Vto. CAE: "
                    + (f.getCaeFechaVencimiento() != null ? fecha.format(f.getCaeFechaVencimiento()) : "-")));

            // Codigo QR de ARCA con los datos del comprobante autorizado
            BarcodeQRCode qr = new BarcodeQRCode(urlQrArca(f));
            doc.add(new Image(qr.createFormXObject(ColorConstants.BLACK, pdf)).setWidth(110).setMarginTop(10));
        }
        return out.toByteArray();
    }

    // Formato oficial del QR de ARCA (RG 4291): URL con los datos del comprobante en JSON codificado en Base64.
    // El receptor se informa como Consumidor Final (99 / 0), igual que al pedir el CAE.
    private String urlQrArca(FacturaVenta f) {
        String json = String.format(Locale.ROOT,
                "{\"ver\":1,\"fecha\":\"%s\",\"cuit\":%d,\"ptoVta\":%d,\"tipoCmp\":%d,\"nroCmp\":%d,"
                        + "\"importe\":%.2f,\"moneda\":\"PES\",\"ctz\":1,\"tipoDocRec\":99,\"nroDocRec\":0,"
                        + "\"tipoCodAut\":\"E\",\"codAut\":%d}",
                new SimpleDateFormat("yyyy-MM-dd").format(f.getFechaEmision()),
                cuitEmisor, f.getPuntoVenta().getNumero(), CBTE_TIPO_FACTURA_C, f.getNumero(),
                f.getImporteTotal(), Long.parseLong(f.getCae().trim()));
        return "https://www.afip.gob.ar/fe/qr/?p="
                + Base64.getEncoder().encodeToString(json.getBytes(StandardCharsets.UTF_8));
    }

    private Cell derecha(String texto) {
        return new Cell().add(new Paragraph(texto).setTextAlignment(TextAlignment.RIGHT));
    }
}