package ar.edu.facturacion.controller;

import ar.edu.facturacion.dto.CatalogosDTO;
import ar.edu.facturacion.service.FacturaService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/catalogos")
public class CatalogoRestController {
    private final FacturaService service;

    public CatalogoRestController(FacturaService service) {
        this.service = service;
    }

    @GetMapping
    public CatalogosDTO listar() {
        return service.obtenerCatalogos();
    }

    @GetMapping("/clientes")
    public Map<String, Object> clientes(@RequestParam(required = false) String texto,
                                        @RequestParam(defaultValue = "0") int page,
                                        @RequestParam(defaultValue = "8") int size) {
        return service.explorarClientes(texto, Math.max(page, 0), size <= 0 ? 8 : size);
    }

     @GetMapping("/articulos")
    public Map<String, Object> articulos(@RequestParam(required = false) String texto,
                                         @RequestParam(defaultValue = "MINORISTA") String lista,
                                         @RequestParam(defaultValue = "0") int page,
                                         @RequestParam(defaultValue = "8") int size) {
        return service.explorarArticulos(texto, lista, Math.max(page, 0), size <= 0 ? 8 : size);
    }
}