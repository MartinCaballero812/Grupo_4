package ar.edu.facturacion.arca;

public class MainArca {
    public static void main(String[] args) {
        try {
            String keyPath = "/Users/martin.caballero/arca/privada_test.key";
            String certPath = "/Users/martin.caballero/arca/certificado.crt";
            long cuil = 20137094623L;      
            int puntoDeVenta = 1;          // el punto de venta dado de alta en ARCA
            int cbteTipo = 11;             // 11 = Factura C

            System.out.println("1. Solicitando Token y Sign a WSAA...");
            String[] auth = AfipWsaaClient.obtenerTokenYSign(keyPath, certPath, "wsfe");
            String token = auth[0];
            String sign = auth[1];
            System.out.println("Autenticado OK.");

            System.out.println("2. Consultando ultimo comprobante...");
            int ultimoNro = AfipWsfeClient.obtenerUltimoComprobante(token, sign, cuil, puntoDeVenta, cbteTipo);
            int nuevoNro = ultimoNro + 1;
            System.out.println("Ultimo registrado: " + ultimoNro + ". Siguiente a emitir: " + nuevoNro);

            System.out.println("3. Enviando factura para obtener CAE...");
            String resultado = AfipWsfeClient.solicitarCae(token, sign, cuil, puntoDeVenta, cbteTipo, nuevoNro, 1500.00);

            System.out.println("\n--- Respuesta WSFEv1 ---");
            System.out.println(resultado);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}