package ar.edu.facturacion.dto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

// Factura completa para cargarla en el formulario y editarla (GET /api/facturas/{id}).
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FacturaEdicionDTO {
    private Long id;
    private Long numeroFactura;
    private String estado;
    private Long clienteId;
    private String clienteTexto;
    private Long condicionIvaId;
    private Long puntoVentaId;
    private Long tipoMonedaId;
    private String observaciones;
    private List<FacturaDetalleDTO> detalles;
}