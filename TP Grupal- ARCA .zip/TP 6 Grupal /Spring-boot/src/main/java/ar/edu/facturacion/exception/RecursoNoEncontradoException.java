package ar.edu.facturacion.exception;

// Se lanza cuando un id (de la factura o de una entidad asociada) no existe. El handler la traduce a 404.
public class RecursoNoEncontradoException extends RuntimeException {
    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
    }
}




