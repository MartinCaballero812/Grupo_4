package ar.edu.facturacion.reportes;

import java.text.SimpleDateFormat;
import ar.edu.facturacion.dto.FacturaReporteDTO;
import ar.edu.facturacion.repository.ConsultasJPQL;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;

public class GeneradorReportes {
    private final ConsultasJPQL consultas;

    public GeneradorReportes(ConsultasJPQL consultas) {
        this.consultas = consultas;
    }

    public void generarExcelTsv(String ruta) throws Exception {
        List<FacturaReporteDTO> datos = consultas.buscarFacturasFiltradas(null, null, null, null);
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {
            pw.println("Numero\tFechaEmision\tCliente\tCondicionIva\tPuntoVenta\tImporteTotal\tCantidadItems");
            for (FacturaReporteDTO d : datos) {
               pw.println(d.getNumeroFactura() + "\t" + new SimpleDateFormat("yyyy-MM-dd").format(d.getFechaEmision()) + "\t"
                    + d.getClienteDenominacion() + "\t" + d.getCondicionIva() + "\t"
                    + d.getPuntoVentaDescripcion() + "\t" + d.getImporteTotal() + "\t"
                    + d.getCantidadItems());
            }
        }
    }

    public void generarPdf(String ruta) throws Exception {
        List<FacturaReporteDTO> datos = consultas.buscarFacturasFiltradas(null, null, null, null);
        PdfWriter writer = new PdfWriter(ruta);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);
        document.add(new Paragraph("Reporte Ejecutivo de Ventas").setBold().setFontSize(16));
        Table table = new Table(UnitValue.createPercentArray(new float[]{1, 2, 2, 2, 2, 1, 1}));
        table.addHeaderCell("Nro");
        table.addHeaderCell("Fecha");
        table.addHeaderCell("Cliente");
        table.addHeaderCell("Condicion IVA");
        table.addHeaderCell("Punto Venta");
        table.addHeaderCell("Importe");
        table.addHeaderCell("Items");
        for (FacturaReporteDTO d : datos) {
            table.addCell(String.valueOf(d.getNumeroFactura()));
            table.addCell(new SimpleDateFormat("yyyy-MM-dd").format(d.getFechaEmision()));
            table.addCell(d.getClienteDenominacion());
            table.addCell(d.getCondicionIva());
            table.addCell(d.getPuntoVentaDescripcion());
            table.addCell(String.valueOf(d.getImporteTotal()));
            table.addCell(String.valueOf(d.getCantidadItems()));
        }
        document.add(table);
        document.close();
    }
}