package ar.edu.facturacion;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import ar.edu.facturacion.model.Articulo;
import ar.edu.facturacion.model.Cliente;
import ar.edu.facturacion.model.FacturaVenta;
import ar.edu.facturacion.model.FacturaVentaDetalle;
import ar.edu.facturacion.model.Marca;
import ar.edu.facturacion.model.PuntoVenta;
import ar.edu.facturacion.repository.ConsultasJPQL;
import ar.edu.facturacion.dto.FacturaReporteDTO;
import ar.edu.facturacion.reportes.GeneradorReportes;

public class Main {

    // Referencia fuerte: si no, el logger puede perder su configuracion
    private static final Logger LOG_HIBERNATE = Logger.getLogger("org.hibernate");

    public static void main(String[] args) {

        // Silenciar los mensajes informativos de Hibernate para que se lea solo el resultado
        LOG_HIBERNATE.setLevel(Level.SEVERE);

        // Iniciar JPA y obtener el EntityManager
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {
            // PASO 1 y 2: cargar los datos de ejemplo y persistirlos
            em.getTransaction().begin();
            DatosEjemplo.cargar(em);
            em.getTransaction().commit();

            // PASO 3: las 20 consultas
            ConsultasJPQL consultas = new ConsultasJPQL(em);

            // Imprimir reporte en consola
                for (FacturaReporteDTO r : consultas.buscarFacturasFiltradas(null, null, null, null)) {
                    System.out.println(r.getNumeroFactura() + " | " + r.getClienteDenominacion()
                        + " | " + r.getCondicionIva() + " | " + r.getImporteTotal()
                        + " | items=" + r.getCantidadItems());
                }
            // Generar archivos
            new GeneradorReportes(consultas).generarPdf("reporte.pdf");
            new GeneradorReportes(consultas).generarExcelTsv("reporte.tsv");
            System.out.println("Archivos reporte.pdf y reporte.tsv generados.");

            System.out.println();
            System.out.println("TP4 - CONSULTAS JPQL (sistema de facturacion)");

            // =================== NIVEL 1 ===================
            titulo(1, "Consulta de entidades completas",
                    "Lista completa de todas las facturas de venta registradas en el sistema.");
            List<Object[]> filas = new ArrayList<>();
            for (FacturaVenta f : consultas.consulta1()) {
                filas.add(new Object[]{f.getNumero(), nombreCliente(f), f.getEstado(),
                        dinero(f.getImporteTotal()), f.getDetalles().size()});
            }
            tabla(new String[]{"Numero", "Cliente", "Estado", "Total", "Detalles"}, filas);

            titulo(2, "Proyeccion de atributos especificos",
                    "Numero, fecha de emision e importe total de todas las facturas.");
            filas = new ArrayList<>();
            for (Object[] r : consultas.consulta2()) {
                filas.add(new Object[]{r[0], r[1], dinero((Double) r[2])});
            }
            tabla(new String[]{"Numero", "Fecha emision", "Importe total"}, filas);

            titulo(3, "Filtrado por igualdad (WHERE)",
                    "Articulos que pertenecen a un rubro con una denominacion especifica.",
                    "rubro = 'Perifericos'");
            filas = new ArrayList<>();
            for (Articulo a : consultas.consulta3("Perifericos")) {
                filas.add(new Object[]{a.getCodigo(), a.getDenominacion()});
            }
            tabla(new String[]{"Codigo", "Articulo"}, filas);

            Date hasta = new Date();
            Date desde = new Date(hasta.getTime() - 45L * 24L * 60L * 60L * 1000L);
            titulo(4, "Filtrado por rango de fechas (BETWEEN)",
                    "Facturas de venta emitidas dentro de un rango de fechas.",
                    "del " + fecha(desde) + " al " + fecha(hasta));
            filas = new ArrayList<>();
            for (FacturaVenta f : consultas.consulta4(desde, hasta)) {
                filas.add(new Object[]{f.getNumero(), f.getFechaEmision(), dinero(f.getImporteTotal())});
            }
            tabla(new String[]{"Numero", "Fecha emision", "Total"}, filas);

            // =================== NIVEL 2 ===================
            titulo(5, "Condicionales complejos (AND / IS NULL)",
                    "Facturas EMITIDA, con total mayor a $10.000 y que no hayan sido anuladas.",
                    "estado = 'EMITIDA', importe minimo = $ 10.000,00");
            filas = new ArrayList<>();
            for (FacturaVenta f : consultas.consulta5("EMITIDA", 10000.0)) {
                filas.add(new Object[]{f.getNumero(), nombreCliente(f), f.getEstado(),
                        dinero(f.getImporteTotal())});
            }
            tabla(new String[]{"Numero", "Cliente", "Estado", "Total"}, filas);

            titulo(6, "Busqueda por patron de texto (LIKE y LOWER)",
                    "Clientes cuya denominacion contenga un texto, o cuyo CUIT/CUIL comience con \"20-\".",
                    "texto = 'mendoza', CUIT comienza con '20-'");
            filas = new ArrayList<>();
            for (Cliente cl : consultas.consulta6("mendoza", "20-")) {
                filas.add(new Object[]{cl.getDenominacion(), cl.getCuitCuil()});
            }
            tabla(new String[]{"Cliente", "CUIT/CUIL"}, filas);

            titulo(7, "Valores distintos y ordenamiento (DISTINCT y ORDER BY)",
                    "Estados posibles registrados en las facturas, sin duplicados y ordenados A-Z.");
            filas = new ArrayList<>();
            for (String estado : consultas.consulta7()) {
                filas.add(new Object[]{estado});
            }
            tabla(new String[]{"Estado"}, filas);

            titulo(8, "Funciones de agregacion (COUNT, SUM, AVG)",
                    "Cantidad de facturas, suma de sus importes totales e importe promedio.");
            Object[] resumen = consultas.consulta8();
            filas = new ArrayList<>();
            filas.add(new Object[]{resumen[0], dinero((Double) resumen[1]),
                    dinero((Double) resumen[2])});
            tabla(new String[]{"Cantidad de facturas", "Suma de importes", "Promedio"}, filas);

            titulo(9, "Operador de inclusion (IN)",
                    "Puntos de venta cuyo numero coincida con una lista de enteros.",
                    "numeros = 1, 2, 5");
            filas = new ArrayList<>();
            for (PuntoVenta p : consultas.consulta9(Arrays.asList(1, 2, 5))) {
                filas.add(new Object[]{p.getNumero(), p.getDescripcion()});
            }
            tabla(new String[]{"Numero", "Descripcion"}, filas);

            // =================== NIVEL 3 ===================
            titulo(10, "Navegacion implicita por relaciones",
                    "Facturas creadas por un usuario (usuarioCarga.usuario).",
                    "usuario = 'usuario1'");
            filas = new ArrayList<>();
            for (FacturaVenta f : consultas.consulta10("usuario1")) {
                filas.add(new Object[]{f.getNumero(), nombreCliente(f), f.getEstado(),
                        dinero(f.getImporteTotal())});
            }
            tabla(new String[]{"Numero", "Cliente", "Estado", "Total"}, filas);

            titulo(11, "INNER JOIN explicito",
                    "Detalles de factura correspondientes a facturas de un punto de venta.",
                    "punto de venta numero = 1");
            filas = new ArrayList<>();
            for (FacturaVentaDetalle d : consultas.consulta11(1)) {
                filas.add(new Object[]{d.getFactura().getNumero(), d.getDescripcion(), d.getCantidad()});
            }
            tabla(new String[]{"Factura", "Articulo", "Cantidad"}, filas);

            titulo(12, "LEFT JOIN (inclusion de nulos)",
                    "Denominacion de cada articulo y de su marca, incluyendo los articulos sin marca.");
            filas = new ArrayList<>();
            for (Object[] r : consultas.consulta12()) {
                filas.add(new Object[]{r[0], r[1] == null ? "(sin marca)" : r[1]});
            }
            tabla(new String[]{"Articulo", "Marca"}, filas);

            titulo(13, "Navegacion multinivel con JOINs combinados",
                    "Facturas que contengan al menos un articulo de una marca especifica.",
                    "marca = 'Logitech'");
            filas = new ArrayList<>();
            for (FacturaVenta f : consultas.consulta13("Logitech")) {
                filas.add(new Object[]{f.getNumero(), nombreCliente(f),
                        dinero(f.getImporteTotal())});
            }
            tabla(new String[]{"Numero", "Cliente", "Total"}, filas);

            titulo(14, "Subconsulta en la clausula WHERE",
                    "Facturas cuyo importe total es mayor al promedio de todas las facturas.",
                    "promedio = " + dinero((Double) consultas.consulta8()[2]));
            filas = new ArrayList<>();
            for (FacturaVenta f : consultas.consulta14()) {
                filas.add(new Object[]{f.getNumero(), nombreCliente(f),
                        dinero(f.getImporteTotal())});
            }
            tabla(new String[]{"Numero", "Cliente", "Total"}, filas);

            // =================== NIVEL 4 ===================
            titulo(15, "Agrupamiento basico (GROUP BY)",
                    "Por punto de venta: cantidad de facturas emitidas y suma total facturada.");
            filas = new ArrayList<>();
            for (Object[] r : consultas.consulta15()) {
                filas.add(new Object[]{r[0], r[1], dinero((Double) r[2])});
            }
            tabla(new String[]{"Punto de venta", "Cantidad de facturas", "Total facturado"}, filas);

            titulo(16, "Agrupamiento con condicional de grupo (HAVING)",
                    "Usuarios de carga que hayan registrado mas de 5 facturas.",
                    "minimo = 5 facturas");
            filas = new ArrayList<>();
            for (Object[] r : consultas.consulta16(5L)) {
                filas.add(new Object[]{r[0], r[1]});
            }
            tabla(new String[]{"Usuario", "Cantidad de facturas"}, filas);

            titulo(17, "Agregacion sobre entidades relacionadas",
                    "Por marca: unidades vendidas (SUM cantidad) y subtotal acumulado.");
            filas = new ArrayList<>();
            for (Object[] r : consultas.consulta17()) {
                filas.add(new Object[]{r[0], r[1], dinero((Double) r[2])});
            }
            tabla(new String[]{"Marca", "Unidades vendidas", "Subtotal"}, filas);

            // =================== NIVEL 5 ===================
            titulo(18, "Subconsulta correlacionada con EXISTS",
                    "Marcas que tienen al menos un articulo facturado en alguna factura.");
            filas = new ArrayList<>();
            for (Marca m : consultas.consulta18()) {
                filas.add(new Object[]{m.getDenominacion()});
            }
            tabla(new String[]{"Marca"}, filas);

            titulo(19, "Subconsulta correlacionada con NOT EXISTS",
                    "Articulos que nunca fueron incluidos en ningun detalle de factura.");
            filas = new ArrayList<>();
            for (Articulo a : consultas.consulta19()) {
                filas.add(new Object[]{a.getCodigo(), a.getDenominacion()});
            }
            tabla(new String[]{"Codigo", "Articulo"}, filas);

            titulo(20, "Proyeccion condicional (CASE WHEN)",
                    "Numero, importe total y categoria (ALTO > $50.000, MEDIO $10.000-$50.000, BAJO < $10.000), "
                    + "de mayor a menor importe.");
            filas = new ArrayList<>();
            for (Object[] r : consultas.consulta20()) {
                filas.add(new Object[]{r[0], dinero((Double) r[1]), r[2]});
            }
            tabla(new String[]{"Numero", "Importe total", "Categoria"}, filas);

            System.out.println();
            System.out.println("Fin de las consultas.");

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

    // =====================================================================
    // Metodos auxiliares para mostrar los resultados de forma ordenada
    // =====================================================================


    private static final int ANCHO = 80;

    private static final DecimalFormatSymbols SIMBOLOS = new DecimalFormatSymbols(Locale.forLanguageTag("es-AR"));
    private static final DecimalFormat DINERO = new DecimalFormat("#,##0.00", SIMBOLOS);
    private static final DecimalFormat ENTERO = new DecimalFormat("#,##0", SIMBOLOS);
    private static final DecimalFormat DECIMAL = new DecimalFormat("#,##0.00", SIMBOLOS);

    // ---------- formatos ----------

    /** 1130382.0 -> "$ 1.130.382,00" */
    private static String dinero(double valor) {
        return "$ " + DINERO.format(valor);
    }

    /** Date -> "29/10/2026" */
    private static String fecha(Date fecha) {
        return new SimpleDateFormat("dd/MM/yyyy").format(fecha);
    }

    private static String nombreCliente(FacturaVenta factura) {
        if (factura == null || factura.getCliente() == null) {
            return "Consumidor Final";
        }
        return factura.getCliente().getDenominacion();
    }

    // ---------- titulo de cada consulta ----------

    private static void titulo(int numero, String nombre, String consigna) {
        titulo(numero, nombre, consigna, null);
    }

    private static void titulo(int numero, String nombre, String consigna, String parametros) {
        System.out.println();
        System.out.println();
        System.out.println(repetir('#', ANCHO));
        System.out.println("#  CONSULTA " + numero + "  |  " + nombre);
        System.out.println(repetir('#', ANCHO));
        imprimirEtiqueta("Consigna  ", consigna);
        if (parametros != null) {
            imprimirEtiqueta("Parametros", parametros);
        }
        System.out.println();
    }

    /** Imprime "  Etiqueta : texto" cortando el texto en varias lineas si es largo. */
    private static void imprimirEtiqueta(String etiqueta, String texto) {
        String prefijo = "  " + etiqueta + " : ";
        String sangria = repetir(' ', prefijo.length());
        int disponible = ANCHO - prefijo.length();
        StringBuilder linea = new StringBuilder();
        boolean primera = true;
        for (String palabra : texto.split(" ")) {
            if (linea.length() > 0 && linea.length() + 1 + palabra.length() > disponible) {
                System.out.println((primera ? prefijo : sangria) + linea);
                linea.setLength(0);
                primera = false;
            }
            if (linea.length() > 0) {
                linea.append(' ');
            }
            linea.append(palabra);
        }
        System.out.println((primera ? prefijo : sangria) + linea);
    }

    // ---------- tabla ----------

    /**
     * Imprime una tabla con bordes. Cada fila es un arreglo con un valor por columna.
     * Los numeros y los importes ("$ ...") se alinean a la derecha; el resto a la izquierda.
     */
    private static void tabla(String[] encabezados, List<Object[]> filas) {
        if (filas.isEmpty()) {
            System.out.println("  (sin resultados: ningun registro cumple la condicion)");
            return;
        }
        int cols = encabezados.length;
        List<String[]> texto = new ArrayList<>();
        boolean[] derecha = new boolean[cols];
        int[] ancho = new int[cols];

        for (int c = 0; c < cols; c++) {
            ancho[c] = encabezados[c].length();
        }
        for (Object[] fila : filas) {
            String[] celdas = new String[cols];
            for (int c = 0; c < cols; c++) {
                Object v = fila[c];
                celdas[c] = comoTexto(v);
                if (v instanceof Number || (v instanceof String && ((String) v).startsWith("$ "))) {
                    derecha[c] = true;
                }
                ancho[c] = Math.max(ancho[c], celdas[c].length());
            }
            texto.add(celdas);
        }

        String borde = borde(ancho);
        System.out.println(borde);
        System.out.println(linea(encabezados, ancho, derecha));
        System.out.println(borde);
        for (String[] celdas : texto) {
            System.out.println(linea(celdas, ancho, derecha));
        }
        System.out.println(borde);
        System.out.println("  Total: " + filas.size() + (filas.size() == 1 ? " resultado" : " resultados"));
    }

    // ---------- internos ----------

    private static String comoTexto(Object v) {
        if (v == null) {
            return "-";
        }
        if (v instanceof Date) {
            return fecha((Date) v);
        }
        if (v instanceof Double || v instanceof Float) {
            double d = ((Number) v).doubleValue();
            return d == Math.floor(d) ? ENTERO.format(d) : DECIMAL.format(d);
        }
        if (v instanceof Number) {
            return ENTERO.format(((Number) v).longValue());
        }
        return v.toString();
    }

    private static String borde(int[] ancho) {
        StringBuilder sb = new StringBuilder("+");
        for (int a : ancho) {
            sb.append(repetir('-', a + 2)).append('+');
        }
        return sb.toString();
    }

    private static String linea(String[] celdas, int[] ancho, boolean[] derecha) {
        StringBuilder sb = new StringBuilder("|");
        for (int c = 0; c < celdas.length; c++) {
            String s = celdas[c];
            String relleno = repetir(' ', ancho[c] - s.length());
            sb.append(' ').append(derecha[c] ? relleno + s : s + relleno).append(" |");
        }
        return sb.toString();
    }

    private static String repetir(char c, int veces) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < veces; i++) {
            sb.append(c);
        }
        return sb.toString();
    }
}