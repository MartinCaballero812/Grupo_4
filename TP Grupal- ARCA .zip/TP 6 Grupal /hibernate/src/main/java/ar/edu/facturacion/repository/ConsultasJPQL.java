package ar.edu.facturacion.repository;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import ar.edu.facturacion.model.Articulo;
import ar.edu.facturacion.model.Cliente;
import ar.edu.facturacion.model.FacturaVenta;
import ar.edu.facturacion.model.FacturaVentaDetalle;
import ar.edu.facturacion.model.Marca;
import ar.edu.facturacion.model.PuntoVenta;


public class ConsultasJPQL {

    private final EntityManager em;

    public ConsultasJPQL(EntityManager em) {
        this.em = em;
    }

    // =====================================================================
    // NIVEL 1: Consultas basicas y proyecciones
    // =====================================================================

    // Consulta 1 - Entidades completas:
    // Obtener la lista completa de todas las facturas de venta registradas en el sistema.
    public List<FacturaVenta> consulta1() {
        return em.createQuery("SELECT f FROM FacturaVenta f ORDER BY f.numero ASC", FacturaVenta.class)
                .getResultList();
    }

    // Consulta 2 - Proyeccion de atributos especificos:
    // Numero de factura, fecha de emision e importe total de todas las facturas.
    public List<Object[]> consulta2() {
        return em.createQuery(
                "SELECT f.numero, f.fechaEmision, f.importeTotal FROM FacturaVenta f ORDER BY f.numero ASC",
                Object[].class)
                .getResultList();
    }

    // Consulta 3 - Filtrado por igualdad (WHERE):
    // Articulos que pertenecen a un rubro con una denominacion especifica.
    public List<Articulo> consulta3(String denominacionRubro) {
        return em.createQuery(
                "SELECT a FROM Articulo a WHERE a.rubro.denominacion = :rubro",
                Articulo.class)
                .setParameter("rubro", denominacionRubro)
                .getResultList();
    }

    // Consulta 4 - Filtrado por rango de fechas (BETWEEN):
    // Facturas de venta emitidas dentro de un rango de fechas.
    public List<FacturaVenta> consulta4(Date desde, Date hasta) {
        return em.createQuery(
                "SELECT f FROM FacturaVenta f WHERE f.fechaEmision BETWEEN :desde AND :hasta ORDER BY f.numero ASC",
                FacturaVenta.class)
                .setParameter("desde", desde)
                .setParameter("hasta", hasta)
                .getResultList();
    }

    // =====================================================================
    // NIVEL 2: Condicionales combinados, texto y agregaciones basicas
    // =====================================================================

    // Consulta 5 - AND / IS NULL:
    // Facturas con estado dado (EMITIDA), importe total superior a un minimo (10000)
    // y que no hayan sido anuladas (fechaAnulacion nula).
    public List<FacturaVenta> consulta5(String estado, double importeMinimo) {
        return em.createQuery(
                "SELECT f FROM FacturaVenta f "
                + "WHERE f.estado = :estado "
                + "AND f.importeTotal > :importeMinimo "
                + "AND f.fechaAnulacion IS NULL "
                + "ORDER BY f.numero ASC",
                FacturaVenta.class)
                .setParameter("estado", estado)
                .setParameter("importeMinimo", importeMinimo)
                .getResultList();
    }

    // Consulta 6 - LIKE y LOWER:
    // Clientes cuya denominacion contenga un texto (sin importar mayusculas)
    // o cuyo CUIT/CUIL comience con "20-".
    public List<Cliente> consulta6(String texto, String prefijoCuit) {
        return em.createQuery(
                "SELECT c FROM Cliente c "
                + "WHERE LOWER(c.denominacion) LIKE :texto "
                + "OR c.cuitCuil LIKE :prefijoCuit",
                Cliente.class)
                .setParameter("texto", "%" + texto.toLowerCase() + "%")
                .setParameter("prefijoCuit", prefijoCuit + "%")
                .getResultList();
    }

    // Consulta 7 - DISTINCT y ORDER BY:
    // Estados posibles registrados en las facturas, sin duplicados y ordenados A-Z.
    public List<String> consulta7() {
        return em.createQuery(
                "SELECT DISTINCT f.estado FROM FacturaVenta f ORDER BY f.estado ASC",
                String.class)
                .getResultList();
    }

    // Consulta 8 - COUNT, SUM, AVG:
    // Cantidad de facturas, suma de sus importes totales y promedio, en un solo arreglo.
    public Object[] consulta8() {
        return em.createQuery(
                "SELECT COUNT(f), SUM(f.importeTotal), AVG(f.importeTotal) FROM FacturaVenta f",
                Object[].class)
                .getSingleResult();
    }

    // Consulta 9 - IN:
    // Puntos de venta cuyo numero coincida con una lista de enteros.
    public List<PuntoVenta> consulta9(List<Integer> numeros) {
        return em.createQuery(
                "SELECT p FROM PuntoVenta p WHERE p.numero IN (:numeros)",
                PuntoVenta.class)
                .setParameter("numeros", numeros)
                .getResultList();
    }

    // =====================================================================
    // NIVEL 3: Navegacion, JOINs y subconsultas simples
    // =====================================================================

    // Consulta 10 - Navegacion implicita (path expression):
    // Facturas creadas por un usuario, navegando usuarioCarga.usuario.
    public List<FacturaVenta> consulta10(String nombreUsuario) {
        return em.createQuery(
                "SELECT f FROM FacturaVenta f WHERE f.usuarioCarga.usuario = :usuario ORDER BY f.numero ASC",
                FacturaVenta.class)
                .setParameter("usuario", nombreUsuario)
                .getResultList();
    }

    // Consulta 11 - INNER JOIN explicito:
    // Detalles de factura de las facturas emitidas por un punto de venta determinado.
    public List<FacturaVentaDetalle> consulta11(int numeroPuntoVenta) {
        return em.createQuery(
                "SELECT d FROM FacturaVentaDetalle d "
                + "JOIN d.factura f "
                + "JOIN f.puntoVenta p "
                + "WHERE p.numero = :numeroPuntoVenta",
                FacturaVentaDetalle.class)
                .setParameter("numeroPuntoVenta", numeroPuntoVenta)
                .getResultList();
    }

    // Consulta 12 - LEFT JOIN:
    // Denominacion de cada articulo y de su marca, incluyendo articulos sin marca.
    public List<Object[]> consulta12() {
        return em.createQuery(
                "SELECT a.denominacion, m.denominacion FROM Articulo a LEFT JOIN a.marca m",
                Object[].class)
                .getResultList();
    }

    // Consulta 13 - Navegacion multinivel con JOINs:
    // Facturas que contengan al menos un detalle de un articulo de una marca especifica.
    public List<FacturaVenta> consulta13(String denominacionMarca) {
        return em.createQuery(
                "SELECT DISTINCT f FROM FacturaVenta f "
                + "JOIN f.detalles d "
                + "JOIN d.listaPrecioArticulo lpa "
                + "JOIN lpa.articulo a "
                + "JOIN a.marca m "
                + "WHERE m.denominacion = :marca "
                + "ORDER BY f.numero ASC",
                FacturaVenta.class)
                .setParameter("marca", denominacionMarca)
                .getResultList();
    }

    // Consulta 14 - Subconsulta en WHERE:
    // Facturas cuyo importeTotal es mayor al promedio de todas las facturas.
    public List<FacturaVenta> consulta14() {
        return em.createQuery(
                "SELECT f FROM FacturaVenta f "
                + "WHERE f.importeTotal > (SELECT AVG(f2.importeTotal) FROM FacturaVenta f2) "
                + "ORDER BY f.numero ASC",
                FacturaVenta.class)
                .getResultList();
    }

    // =====================================================================
    // NIVEL 4: GROUP BY y HAVING
    // =====================================================================

    // Consulta 15 - GROUP BY:
    // Descripcion del punto de venta, cantidad de facturas y suma total facturada.
    public List<Object[]> consulta15() {
        return em.createQuery(
                "SELECT p.descripcion, COUNT(f), SUM(f.importeTotal) "
                + "FROM FacturaVenta f JOIN f.puntoVenta p "
                + "GROUP BY p.descripcion",
                Object[].class)
                .getResultList();
    }

    // Consulta 16 - GROUP BY con HAVING:
    // Usuarios de carga que registraron mas de N facturas (N = 5).
    public List<Object[]> consulta16(long minimoFacturas) {
        return em.createQuery(
                "SELECT u.usuario, COUNT(f) "
                + "FROM FacturaVenta f JOIN f.usuarioCarga u "
                + "GROUP BY u.usuario "
                + "HAVING COUNT(f) > :minimo",
                Object[].class)
                .setParameter("minimo", minimoFacturas)
                .getResultList();
    }

    // Consulta 17 - Agregacion sobre entidades relacionadas:
    // Por marca: unidades vendidas (SUM cantidad) y subtotal acumulado.
    public List<Object[]> consulta17() {
        return em.createQuery(
                "SELECT m.denominacion, SUM(d.cantidad), SUM(d.importeSubtotal) "
                + "FROM FacturaVentaDetalle d "
                + "JOIN d.listaPrecioArticulo lpa "
                + "JOIN lpa.articulo a "
                + "JOIN a.marca m "
                + "GROUP BY m.denominacion",
                Object[].class)
                .getResultList();
    }

    // =====================================================================
    // NIVEL 5: EXISTS, NOT EXISTS y CASE WHEN
    // =====================================================================

    // Consulta 18 - EXISTS:
    // Marcas que tienen al menos un articulo facturado en alguna factura.
    public List<Marca> consulta18() {
        return em.createQuery(
                "SELECT m FROM Marca m WHERE EXISTS ("
                + "SELECT d.id FROM FacturaVentaDetalle d "
                + "JOIN d.listaPrecioArticulo lpa "
                + "JOIN lpa.articulo a "
                + "WHERE a.marca = m)",
                Marca.class)
                .getResultList();
    }

    // Consulta 19 - NOT EXISTS:
    // Articulos que nunca fueron incluidos en ningun detalle de factura.
    public List<Articulo> consulta19() {
        return em.createQuery(
                "SELECT a FROM Articulo a WHERE NOT EXISTS ("
                + "SELECT d.id FROM FacturaVentaDetalle d "
                + "JOIN d.listaPrecioArticulo lpa "
                + "WHERE lpa.articulo = a)",
                Articulo.class)
                .getResultList();
    }

    // Consulta 20 - CASE WHEN:
    // Numero, importe total y "Categoria" (ALTO > 50000, MEDIO 10000-50000, BAJO < 10000),
    // ordenado de mayor a menor importe.
    public List<Object[]> consulta20() {
        return em.createQuery(
                "SELECT f.numero, f.importeTotal, "
                + "CASE WHEN f.importeTotal > 50000 THEN 'ALTO VALOR' "
                + "     WHEN f.importeTotal >= 10000 THEN 'MEDIO VALOR' "
                + "     ELSE 'BAJO VALOR' END "
                + "FROM FacturaVenta f "
                + "ORDER BY f.numero ASC",
                Object[].class)
                .getResultList();
    }

     // Reporte ejecutivo de ventas: proyeccion directa a FacturaReporteDTO con filtros opcionales.
    public java.util.List<ar.edu.facturacion.dto.FacturaReporteDTO> buscarFacturasFiltradas(
            java.util.Date fechaDesde, java.util.Date fechaHasta, String estado, Double montoMinimo) {
        StringBuilder jpql = new StringBuilder(
            "SELECT new ar.edu.facturacion.dto.FacturaReporteDTO("
            + "   f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'), "
            + "   ci.denominacion, pv.descripcion, f.importeTotal, COUNT(d), f.cae"
            + ") "
            + "FROM FacturaVenta f "
            + "LEFT JOIN f.cliente c "
            + "JOIN f.condicionIva ci "
            + "JOIN f.puntoVenta pv "
            + "JOIN f.detalles d "
            + "WHERE 1=1 "
        );

        java.util.Map<String, Object> params = new java.util.HashMap<>();

        if (fechaDesde != null) {
            jpql.append("AND f.fechaEmision >= :fechaDesde ");
            params.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            jpql.append("AND f.fechaEmision <= :fechaHasta ");
            params.put("fechaHasta", fechaHasta);
        }
        if (estado != null && !estado.trim().isEmpty()) {
            jpql.append("AND f.estado = :estado ");
            params.put("estado", estado);
        }
        if (montoMinimo != null) {
            jpql.append("AND f.importeTotal >= :montoMinimo ");
            params.put("montoMinimo", montoMinimo);
        }

        jpql.append("GROUP BY f.id, f.numero, f.fechaEmision, COALESCE(c.denominacion, 'Consumidor Final'), "
            + "ci.denominacion, pv.descripcion, f.importeTotal, f.cae ");
        jpql.append("ORDER BY f.numero ASC");

        javax.persistence.TypedQuery<ar.edu.facturacion.dto.FacturaReporteDTO> query =
            em.createQuery(jpql.toString(), ar.edu.facturacion.dto.FacturaReporteDTO.class);
        params.forEach(query::setParameter);

        return query.getResultList();
    }

}
