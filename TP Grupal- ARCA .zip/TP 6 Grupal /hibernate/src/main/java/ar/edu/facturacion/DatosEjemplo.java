package ar.edu.facturacion;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import ar.edu.facturacion.model.*;

/**
 * PASO 1 y 2: arma los datos de ejemplo y los persiste.
 * Se llama dentro de una transaccion abierta por el Main.
 * Cantidades: 10 usuarios, 20 clientes, 100 articulos (200 precios: mayorista y minorista) y 30 facturas.
 */
public class DatosEjemplo {

    private static final double IVA = 0.21;

    public static void cargar(EntityManager em) {

        // Evita cargar los datos dos veces: los usuarios se crean primero, si ya hay alguno es que ya se cargo todo
        Long existentes = em.createQuery("SELECT COUNT(u) FROM Usuario u", Long.class)
                .getSingleResult();
        if (existentes > 0) {
            System.out.println(">>> Ya hay datos cargados, no se cargan de nuevo");
            return;
        }

        Date ahora = new Date();

        // ===== USUARIOS =====
        String[] nomU = {"Martin", "Lucia", "Carlos", "Ana", "Pedro", "Sofia", "Diego", "Valeria", "Juan", "Camila"};
        String[] apeU = {"Caballero", "Gomez", "Perez", "Lopez", "Diaz", "Ruiz", "Sosa", "Vega", "Rios", "Luna"};
        List<Usuario> usuarios = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Usuario u = new Usuario();
            u.setUsuario("usuario" + (i + 1));
            u.setClave("clave" + (i + 1));
            u.setNombre(nomU[i]);
            u.setApellido(apeU[i]);
            em.persist(u);
            usuarios.add(u);
        }
        Usuario admin = usuarios.get(0);

        // ===== RUBROS =====
        String[] nomR = {"Perifericos", "Notebooks", "Monitores", "Redes", "Almacenamiento",
                "Audio", "Impresion", "Gaming", "Accesorios", "Software"};
        List<Rubro> rubros = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Rubro r = new Rubro();
            r.setDenominacion(nomR[i]);
            r.setCodigo(100 + i);
            completarAuditoria(r, admin, ahora);
            em.persist(r);
            rubros.add(r);
        }

        // ===== MARCAS =====
        String[] nomM = {"Logitech", "Samsung", "HP", "Lenovo", "Kingston",
                "Asus", "Sony", "Dell", "Razer", "Epson"};
        List<Marca> marcas = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            Marca m = new Marca();
            m.setDenominacion(nomM[i]);
            m.setCodigo(200 + i);
            completarAuditoria(m, admin, ahora);
            em.persist(m);
            marcas.add(m);
        }

        // ===== PUNTOS DE VENTA =====
        String[] descPV = {"Casa central", "Sucursal Centro", "Sucursal Norte", "Sucursal Sur", "Sucursal Este",
                "Sucursal Oeste", "Deposito", "Ventas online", "Mostrador", "Telefonico"};
        List<PuntoVenta> puntos = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            PuntoVenta p = new PuntoVenta();
            p.setNumero(i + 1);
            p.setDescripcion(descPV[i]);
            p.setTipoEmision("CAE");
            p.setDomicilioComercial(descPV[i] + ", Mendoza");
            completarAuditoria(p, admin, ahora);
            em.persist(p);
            puntos.add(p);
        }

        // ===== CONDICIONES DE IVA =====
        String[] nomIva = {"Responsable Inscripto", "Responsable No Inscripto", "No Responsable", "Sujeto Exento",
                "Consumidor Final", "Monotributista", "Sujeto No Categorizado", "Proveedor del Exterior",
                "Cliente del Exterior", "IVA Liberado"};
        List<CondicionIva> ivas = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            CondicionIva c = new CondicionIva();
            c.setCodigoAfip(i + 1);
            c.setDenominacion(nomIva[i]);
            completarAuditoria(c, admin, ahora);
            em.persist(c);
            ivas.add(c);
        }

        // ===== TIPOS DE MONEDA =====
        String[] codM = {"PES", "DOL", "EUR", "BRL", "CLP", "UYU", "GBP", "JPY", "CHF", "MXN"};
        String[] denM = {"Pesos Argentinos", "Dolar Estadounidense", "Euro", "Real", "Peso Chileno",
                "Peso Uruguayo", "Libra Esterlina", "Yen", "Franco Suizo", "Peso Mexicano"};
        String[] simM = {"$", "U$S", "EUR", "R$", "CLP", "UYU", "GBP", "JPY", "CHF", "MXN"};
        List<TipoMoneda> monedas = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            TipoMoneda t = new TipoMoneda();
            t.setCodigoAfip(codM[i]);
            t.setDenominacion(denM[i]);
            t.setSimbolo(simM[i]);
            completarAuditoria(t, admin, ahora);
            em.persist(t);
            monedas.add(t);
        }

        // ===== LISTAS DE PRECIO (solo dos: mayorista y minorista) =====
        String[] nomLP = {"Lista mayorista", "Lista minorista"};
        String[] codLP = {"MAYORISTA", "MINORISTA"};
        List<ListaPrecio> listas = new ArrayList<>();
        for (int i = 0; i < nomLP.length; i++) {
            ListaPrecio l = new ListaPrecio();
            l.setCodigo(codLP[i]);
            l.setDenominacion(nomLP[i]);
            completarAuditoria(l, admin, ahora);
            em.persist(l);
            listas.add(l);
        }

        // ===== CONTACTOS Y DOMICILIOS (se guardan ANTES que los clientes) =====
        String[] calles = {"San Martin", "Belgrano", "Rivadavia", "Mitre", "Sarmiento",
                "Las Heras", "Godoy Cruz", "Colon", "Alem", "Urquiza",
                "Lavalle", "Maipu", "Corrientes", "Salta", "Tucuman",
                "Jujuy", "Catamarca", "San Juan", "Buenos Aires", "Peru"};
        List<Contacto> contactos = new ArrayList<>();
        List<Domicilio> domicilios = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            Contacto c = new Contacto();
            c.setEmail("cliente" + (i + 1) + "@mail.com");
            c.setTelefono("261400" + String.format("%04d", i + 1));
            c.setCelular("261600" + String.format("%04d", i + 1));
            em.persist(c);
            contactos.add(c);

            Domicilio d = new Domicilio();
            d.setNombreCalle(calles[i]);
            d.setNumeroCalle(String.valueOf(100 * (i + 1)));
            em.persist(d);
            domicilios.add(d);
        }

        // ===== CLIENTES (20: personas con CUIL 20-/27- y empresas con CUIT 30-; digito verificador valido) =====
        String[] denC = {"Juan Perez", "Maria Gonzalez", "Carlos Rodriguez", "Laura Fernandez", "Jorge Martinez",
                "Ana Sanchez", "Pedro Romero", "Lucia Torres", "Distribuidora Andes SA", "Tecno Mendoza SRL",
                "Roberto Diaz", "Silvia Morales", "Fernando Castro", "Gabriela Herrera", "Martin Ortiz",
                "Patricia Navarro", "Ricardo Suarez", "Comercial Cuyo SA", "Servicios Informaticos Huarpe SRL",
                "Mendoza Soluciones SA"};
        String[] prefijos = {"20", "20", "20", "20", "20", "27", "27", "27", "30", "30",
                "20", "27", "20", "27", "20", "27", "20", "30", "30", "30"};
        List<Cliente> clientes = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            Cliente cl = new Cliente();
            cl.setCuitCuil(generarCuit(prefijos[i], 10000000 + i * 1111111));
            cl.setDenominacion(denC[i]);
            cl.setContacto(contactos.get(i));
            cl.setDomicilio(domicilios.get(i));
            completarAuditoria(cl, admin, ahora);
            em.persist(cl);
            clientes.add(cl);
        }

        // ===== ARTICULOS (100: 9 por rubro mas los 10 originales) =====
        // El articulo 9 (indice 8) no tiene marca; el articulo 10 (indice 9) nunca se factura
        String[] denA = {"Teclado mecanico", "Notebook 15 pulgadas", "Monitor 24 pulgadas", "Router WiFi",
                "Disco SSD 1TB", "Auriculares", "Impresora laser", "Mouse gamer", "Cable HDMI", "Antivirus anual"};
        // Los 90 nuevos, de a 10 en el orden de los rubros: Perifericos, Notebooks, Monitores, Redes,
        // Almacenamiento, Audio, Impresion, Gaming, Accesorios, Software
               String[] denNuevos = {
                "Teclado inalambrico", "Notebook 14 pulgadas", "Monitor 27 pulgadas", "Switch 8 puertos", "Disco rigido 2TB",
                "Parlantes bluetooth", "Impresora multifuncion", "Silla gamer", "Cable USB-C", "Office hogar",
                "Teclado mecanico", "Notebook gamer 17 pulgadas", "Monitor curvo 32 pulgadas", "Router WiFi", "Pendrive 64GB",
                "Microfono USB", "Impresora a tinta", "Teclado gamer RGB", "Hub USB 4 puertos", "Antivirus anual",
                "Webcam Full HD", "Notebook 15 pulgadas", "Monitor 22 pulgadas", "Access point", "Pendrive 128GB",
                "Auriculares", "Cartucho de tinta negro", "Joystick inalambrico", "Cargador universal", "Licencia de Windows",
                "Mouse pad grande", "Notebook 15 pulgadas Ryzen", "Monitor 24 pulgadas", "Placa de red PCI", "Tarjeta SD 128GB",
                "Barra de sonido", "Cartucho de tinta color", "Mouse gamer", "Soporte para notebook", "Suite de diseno",
                "Teclado mecanico", "Notebook 15 pulgadas Core i5", "Monitor 27 pulgadas 4K", "Cable de red 10m", "Disco SSD 1TB",
                "Auriculares con microfono", "Toner negro", "Auriculares gamer", "Funda para notebook", "Antivirus empresarial",
                "Combo teclado y mouse", "Notebook 14 pulgadas Core i7", "Monitor 19 pulgadas", "Router WiFi", "Disco SSD 2TB",
                "Parlante portatil", "Toner color", "Alfombrilla gamer", "Cable HDMI", "Licencia de Office",
                "Lector de codigo de barras", "Notebook 16 pulgadas Core i9", "Monitor 34 pulgadas ultrawide", "Router 4G", "Disco externo 1TB",
                "Auriculares in-ear", "Impresora laser", "Control para consola", "Adaptador HDMI a VGA", "Software de gestion",
                "Tablet digitalizadora", "Netbook 11 pulgadas", "Monitor portatil 15 pulgadas", "Cable de red 20m", "Disco externo 2TB",
                "Placa de sonido", "Papel fotografico", "Mouse gamer", "Cable DisplayPort", "Software de contabilidad",
                "Presentador inalambrico", "Notebook 15 pulgadas Ryzen 7", "Monitor 24 pulgadas 144Hz", "Patchera 24 puertos", "Memoria RAM 16GB",
                "Microfono de solapa", "Resma papel A4", "Capturadora de video", "Base refrigerante", "Licencia de VPN"};
        // Stock actual: los 10 originales cubren todos los casos (alto, justo el minimo mayorista de 10, bajo y sin stock)
        double[] stockOriginal = {120, 80, 45, 30, 25, 18, 10, 6, 3, 0};
        double[] stockCiclo = {200, 150, 90, 60, 40, 25, 15, 10, 6, 0};
        List<Articulo> articulos = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            Articulo a = new Articulo();
            a.setCodigo("ART-" + String.format("%03d", i + 1));
            a.setDenominacion(i < 10 ? denA[i] : denNuevos[i - 10]);
            a.setStock(i < 10 ? stockOriginal[i] : stockCiclo[i % 10]);
            a.setRubro(rubros.get(i % 10));
                        if (i != 8) {
                a.setMarca(marcas.get((i % 10 + i / 10) % 10)); // la marca rota por fila: un mismo nombre sale con otra marca
            }
            completarAuditoria(a, admin, ahora);
            em.persist(a);
            articulos.add(a);
        }

        // ===== LISTA PRECIO ARTICULO (cada articulo tiene un precio en la lista mayorista y otro en la minorista) =====
        List<ListaPrecioArticulo> preciosMayorista = new ArrayList<>();
        List<ListaPrecioArticulo> preciosMinorista = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            double precioMinorista = 3000.0 + 4500.0 * (i % 10) + 750.0 * (i / 10);

            ListaPrecioArticulo min = new ListaPrecioArticulo();
            min.setListaPrecio(listas.get(1));           // minorista
            min.setArticulo(articulos.get(i));
            min.setPrecioVenta(precioMinorista);
            completarAuditoria(min, admin, ahora);
            em.persist(min);
            preciosMinorista.add(min);

            ListaPrecioArticulo may = new ListaPrecioArticulo();
            may.setListaPrecio(listas.get(0));           // mayorista
            may.setArticulo(articulos.get(i));
            may.setPrecioVenta(Math.round(precioMinorista * 80.0) / 100.0); // el mayorista es 20% mas barato
            completarAuditoria(may, admin, ahora);
            em.persist(may);
            preciosMayorista.add(may);
        }

        // ===== FACTURAS (30), cada una con 1 a 3 detalles =====
        // Todas PENDIENTE: EMITIDA / RECHAZADA dependen de la respuesta de AFIP (se completa mas adelante)
        String estado = "PENDIENTE";
        for (int i = 0; i < 30; i++) {
            Cliente cliente = clientes.get(i % 20);
            boolean empresa = cliente.getCuitCuil().startsWith("30"); // las empresas compran por lista mayorista

            FacturaVenta f = new FacturaVenta();
            f.setNumero((long) (i + 1));
            f.setFechaEmision(haceDias(ahora, (29 - i) * 3));
            f.setCliente(cliente);
            // Empresas (CUIT 30): Responsable Inscripto. Resto: Monotributista / Consumidor Final
            f.setCondicionIva(empresa ? ivas.get(0) : (i % 2 == 0 ? ivas.get(5) : ivas.get(4)));
            f.setTipoMoneda(monedas.get(0));          // todo en pesos: los precios estan en pesos
            f.setPuntoVenta(puntos.get(i % 3));       // 3 puntos de venta en uso
            f.setEstado(estado);

            // Las primeras 6 las carga el mismo usuario (sirve para la consulta con HAVING > 5)
            Usuario carga = (i < 6) ? usuarios.get(0) : usuarios.get(i % 10);
            completarAuditoria(f, carga, ahora);

            // Detalles: el articulo 10 (Antivirus anual, indice 9) nunca se factura
            List<ListaPrecioArticulo> lista = empresa ? preciosMayorista : preciosMinorista;
            double total = 0;
            int cantidadDetalles = 1 + (i % 3);
            for (int k = 0; k < cantidadDetalles; k++) {
                int idx = (i * 7 + k * 13) % 100;
                if (idx == 9) {
                    idx = 10;
                }
                ListaPrecioArticulo lpa = lista.get(idx);
                double cantidad = 1 + ((i + k) % 4);
                if (empresa) {
                    cantidad *= 10; // lista mayorista: minimo 10 unidades por articulo
                }
                double precio = lpa.getPrecioVenta();
                double bonificacion = ((i + k) % 4 == 0) ? 10.0 : 0.0;

                double subtotal = cantidad * precio;
                double neto = subtotal * (1 - bonificacion / 100.0);
                double iva = neto * IVA;

                FacturaVentaDetalle d = new FacturaVentaDetalle();
                d.setListaPrecioArticulo(lpa);
                d.setDescripcion(lpa.getArticulo().getDenominacion());
                d.setCantidad(cantidad);
                d.setPrecioUnitario(precio);
                d.setImporteSubtotal(subtotal);
                d.setPorcentajeBonificacion(bonificacion);
                d.setImporteNeto(neto);
                d.setImporteIva(iva);
                f.agregarDetalle(d);
                total += neto + iva;
            }
            f.setImporteTotal(total);

            // Factura pendiente: nada cobrado, el saldo es el total.
            // CAE, vencimiento del CAE, resultado y motivo de rechazo quedan vacios (los devuelve AFIP).
            f.setImporteCobrado(0);
            f.setImporteSaldo(total);

            // Un solo persist de la cabecera: los detalles entran por cascada
            em.persist(f);
        }

        System.out.println(">>> Datos de ejemplo cargados");
    }

    // ---------- utilidades ----------

    private static Date haceDias(Date base, int dias) {
        return new Date(base.getTime() - dias * 24L * 60L * 60L * 1000L);
    }

    private static void completarAuditoria(AuditoriaApp a, Usuario u, Date fecha) {
        a.setUsuarioCarga(u);
        a.setUsuarioModificacion(u);
        a.setFechaAlta(fecha);
        a.setFechaModificacion(fecha);
    }

    /** Arma un CUIT "PP-NNNNNNNN-D" con digito verificador valido (modulo 11). */
    private static String generarCuit(String prefijo, int numero) {
        while (true) {
            String base = prefijo + String.format("%08d", numero);
            int[] pesos = {5, 4, 3, 2, 7, 6, 5, 4, 3, 2};
            int suma = 0;
            for (int j = 0; j < 10; j++) {
                suma += Character.getNumericValue(base.charAt(j)) * pesos[j];
            }
            int resto = suma % 11;
            int dv = (resto == 0) ? 0 : 11 - resto;
            if (dv != 10) {                      // con 10 el CUIT no existe: probamos el siguiente numero
                return prefijo + "-" + String.format("%08d", numero) + "-" + dv;
            }
            numero++;
        }
    }
}